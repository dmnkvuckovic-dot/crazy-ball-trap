import React, { useEffect, useRef, useState, useCallback } from 'react';
import { BallTrapGame } from './threeScene';
import { HUD } from '../components/HUD';
import { CampaignLevel, FloatingText, GameDifficulty, GameMode, GameStats, WeaponSkin } from './types';

interface GameCanvasProps {
  mode: GameMode;
  level?: CampaignLevel;
  difficulty?: GameDifficulty;
  weaponSkin: WeaponSkin;
  onExit: () => void;
}

export const GameCanvas: React.FC<GameCanvasProps> = ({
  mode,
  level,
  difficulty = 'normal',
  weaponSkin,
  onExit,
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const gameRef = useRef<BallTrapGame | null>(null);

  // React State for HUD mirror
  const [stats, setStats] = useState<GameStats>({
    score: 0,
    highScore: 0,
    claysHit: 0,
    claysTotal: 0,
    chickensHit: 0,
    shotsFired: 0,
    combo: 0,
    maxCombo: 0,
    accuracy: 100,
  });
  const [ammo, setAmmo] = useState<number>(weaponSkin.capacity);
  const [maxAmmo, setMaxAmmo] = useState<number>(weaponSkin.capacity);
  const [isReloading, setIsReloading] = useState<boolean>(false);
  const [isInfiniteAmmo, setIsInfiniteAmmo] = useState<boolean>(false);
  const [timeRemaining, setTimeRemaining] = useState<number>(level ? level.duration : 60);
  const [hitmarker, setHitmarker] = useState<boolean>(false);
  const [floatingTexts, setFloatingTexts] = useState<FloatingText[]>([]);
  const [isLocked, setIsLocked] = useState<boolean>(false);
  const [isPaused, setIsPaused] = useState<boolean>(false);
  const [gameOver, setGameOver] = useState<{ won: boolean; stats: GameStats } | null>(null);

  // Timer tick for HUD state sync
  useEffect(() => {
    const interval = setInterval(() => {
      if (gameRef.current && gameRef.current.isRunning && !gameRef.current.isPaused) {
        setTimeRemaining(Math.max(0, Math.round(gameRef.current.timeRemaining)));
        setIsInfiniteAmmo(gameRef.current.isInfiniteAmmo);
      }
    }, 150);
    return () => clearInterval(interval);
  }, []);

  // Initialize Three.js Game Engine
  useEffect(() => {
    if (!mountRef.current) return;

    const game = new BallTrapGame(mountRef.current, weaponSkin, {
      onScoreUpdate: (newStats) => setStats({ ...newStats }),
      onAmmoUpdate: (curr, max, reloading) => {
        setAmmo(curr);
        setMaxAmmo(max);
        setIsReloading(reloading);
      },
      onFloatingText: (item) => {
        setFloatingTexts((prev) => [...prev.slice(-6), item]);
        setTimeout(() => {
          setFloatingTexts((prev) => prev.filter((t) => t.id !== item.id));
        }, 1200);
      },
      onHitmarker: () => {
        setHitmarker(true);
        setTimeout(() => setHitmarker(false), 90);
      },
      onGameOver: (won, finalStats) => {
        setGameOver({ won, stats: { ...finalStats } });
        if (document.pointerLockElement) {
          document.exitPointerLock();
        }
      },
    });

    gameRef.current = game;
    game.startGame(mode, level, difficulty);

    // Resize listener
    const handleResize = () => game.handleResize();
    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      game.dispose();
      gameRef.current = null;
    };
  }, [mode, level, difficulty, weaponSkin]);

  // Request Pointer Lock on container
  const requestPointerLock = useCallback(() => {
    if (mountRef.current && !document.pointerLockElement) {
      mountRef.current.requestPointerLock?.();
    }
  }, []);

  // Pointer lock change listener
  useEffect(() => {
    const onPointerLockChange = () => {
      const locked = document.pointerLockElement === mountRef.current;
      setIsLocked(locked);
    };

    document.addEventListener('pointerlockchange', onPointerLockChange);
    return () => {
      document.removeEventListener('pointerlockchange', onPointerLockChange);
    };
  }, []);

  // Mouse & Keyboard Event Handlers
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (document.pointerLockElement === mountRef.current && gameRef.current) {
        gameRef.current.handleLookDelta(e.movementX, e.movementY);
      }
    };

    const handleMouseDown = (e: MouseEvent) => {
      if (!gameRef.current) return;
      if (e.button === 0) {
        // Left click: Shoot or Lock
        if (!document.pointerLockElement && !gameOver && !isPaused) {
          requestPointerLock();
        }
        gameRef.current.shoot();
      } else if (e.button === 2) {
        // Right click: Aim Down Sights (ADS)
        e.preventDefault();
        gameRef.current.toggleAimDownSights(true);
      }
    };

    const handleMouseUp = (e: MouseEvent) => {
      if (!gameRef.current) return;
      if (e.button === 2) {
        // Release right click: return to hipfire
        e.preventDefault();
        gameRef.current.toggleAimDownSights(false);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (!gameRef.current) return;
      if (e.code === 'KeyR') {
        gameRef.current.reload();
      } else if (e.code === 'KeyP' || e.code === 'Escape') {
        togglePause();
      }
    };

    const handleContextMenu = (e: MouseEvent) => {
      e.preventDefault(); // Prevent browser context menu on right click
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mousedown', handleMouseDown);
    window.addEventListener('mouseup', handleMouseUp);
    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('contextmenu', handleContextMenu);

    return () => {
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mousedown', handleMouseDown);
      window.removeEventListener('mouseup', handleMouseUp);
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('contextmenu', handleContextMenu);
    };
  }, [gameOver, isPaused, requestPointerLock]);

  const handleShoot = () => {
    if (gameRef.current) {
      gameRef.current.shoot();
    }
  };

  const handleReload = () => {
    if (gameRef.current) {
      gameRef.current.reload();
    }
  };

  const handleToggleADS = () => {
    if (gameRef.current) {
      gameRef.current.toggleAimDownSights();
    }
  };

  const togglePause = () => {
    if (!gameRef.current) return;
    if (isPaused) {
      gameRef.current.resumeGame();
      setIsPaused(false);
      requestPointerLock();
    } else {
      gameRef.current.pauseGame();
      setIsPaused(true);
      if (document.pointerLockElement) {
        document.exitPointerLock();
      }
    }
  };

  const handleRestart = () => {
    setGameOver(null);
    setIsPaused(false);
    if (gameRef.current) {
      gameRef.current.startGame(mode, level, difficulty);
      requestPointerLock();
    }
  };

  const handleTouchLookDelta = (dx: number, dy: number) => {
    if (gameRef.current) {
      gameRef.current.handleLookDelta(dx, dy, 0.0035);
    }
  };

  return (
    <div className="relative w-full h-full bg-slate-950 overflow-hidden select-none">
      {/* 3D Canvas Container */}
      <div
        ref={mountRef}
        className="w-full h-full cursor-crosshair"
        onClick={() => {
          if (!isLocked && !isPaused && !gameOver) {
            requestPointerLock();
          }
        }}
      />

      {/* Interactive HUD Overlay */}
      <HUD
        stats={stats}
        ammo={ammo}
        maxAmmo={maxAmmo}
        isReloading={isReloading}
        isInfiniteAmmo={isInfiniteAmmo}
        timeRemaining={timeRemaining}
        levelName={level ? level.title : mode === 'arcade' ? 'Mode Arcade Infini' : 'Entraînement Libre'}
        targetCount={level ? level.targetCount : undefined}
        hitmarker={hitmarker}
        floatingTexts={floatingTexts}
        isLocked={isLocked}
        isPaused={isPaused}
        gameOver={gameOver}
        currentSkin={weaponSkin}
        onShoot={handleShoot}
        onReload={handleReload}
        onToggleADS={handleToggleADS}
        onTogglePause={togglePause}
        onRequestPointerLock={requestPointerLock}
        onRestart={handleRestart}
        onExitToMenu={onExit}
        onTouchLookDelta={handleTouchLookDelta}
      />
    </div>
  );
};
