export type GameMode = 'arcade' | 'campaign' | 'training';

export type GameDifficulty = 'easy' | 'normal' | 'hardcore';

export interface WeaponSkin {
  id: string;
  name: string;
  description: string;
  unlocked: boolean;
  requiredScore?: number;
  stockColor: string; // Wood / Carbon / Gold / Neon
  barrelColor: string;
  receiverColor: string;
  accentColor: string;
  capacity: number; // 2 or 6
  reloadSpeed: number; // multiplier
}

export interface TargetEntity {
  id: string;
  type: 'clay' | 'chicken_classic' | 'chicken_rocket' | 'chicken_parachute' | 'chicken_golden';
  position: { x: number; y: number; z: number };
  velocity: { x: number; y: number; z: number };
  rotation: { x: number; y: number; z: number };
  rotVelocity: { x: number; y: number; z: number };
  radius: number;
  points: number;
  isHit: boolean;
  isBonus?: boolean;
  age: number;
  maxAge: number;
  flapTime?: number;
  goldenGlow?: boolean;
}

export interface ParticleEffect {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  color: string;
  size: number;
  life: number;
  maxLife: number;
  type: 'clay_shard' | 'feather' | 'smoke' | 'spark' | 'golden_star';
}

export interface FloatingText {
  id: string;
  text: string;
  x: number;
  y: number;
  color: string;
  scale: number;
  opacity: number;
}

export interface CampaignLevel {
  id: number;
  title: string;
  subtitle: string;
  description: string;
  targetCount: number;
  duration: number; // seconds
  requiredScore: number;
  claySpeedMultiplier: number;
  chickenFrequency: number;
  doubleTrapChance: number;
  windSpeed: number; // m/s
  unlocked: boolean;
  highScore: number;
  stars: number; // 0 to 3
}

export interface GameStats {
  score: number;
  highScore: number;
  claysHit: number;
  claysTotal: number;
  chickensHit: number;
  shotsFired: number;
  combo: number;
  maxCombo: number;
  accuracy: number;
}
