/**
 * CRAZY BALL TRAP - 3D Engine & Ballistic Physics
 * High-performance Three.js engine with procedural targets, particle physics, and first-person shooter kinematics
 */
import * as THREE from 'three';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import { soundEngine } from './audio';
import {
  createBallTrapEnvironment,
  createCartoonChickenModel,
  createClayDiscMesh,
  createShotgunModel,
} from './models';
import { CampaignLevel, FloatingText, GameDifficulty, GameMode, GameStats, TargetEntity, WeaponSkin } from './types';

// Pre-allocated math variables for zero-GC render loop
const _vec3A = new THREE.Vector3();
const _vec3B = new THREE.Vector3();
const _vec2 = new THREE.Vector2();
const _raycaster = new THREE.Raycaster();

export interface GameCallbacks {
  onScoreUpdate: (stats: GameStats) => void;
  onAmmoUpdate: (current: number, max: number, isReloading: boolean) => void;
  onFloatingText: (text: FloatingText) => void;
  onHitmarker: (isHeadshot?: boolean) => void;
  onGameOver: (won: boolean, finalStats: GameStats) => void;
}

export class BallTrapGame {
  private container: HTMLElement;
  private callbacks: GameCallbacks;

  // Three.js core
  public scene: THREE.Scene;
  public camera: THREE.PerspectiveCamera;
  public renderer: THREE.WebGLRenderer;
  private isSoftwareGl: boolean = false;
  private animFrameId: number = 0;
  private clock: THREE.Clock;

  // Gun & Camera
  public gunContainer: THREE.Group;
  private gunGroup: THREE.Group | null = null;
  private muzzleFlash: THREE.Group | null = null;
  private flashLight: THREE.PointLight | null = null;
  private gunRestPos = new THREE.Vector3(0.24, -0.22, -0.48);
  private gunAdsPos = new THREE.Vector3(0, -0.165, -0.38);
  private gunTargetPos = new THREE.Vector3(0.24, -0.22, -0.48);
  private gunCurrentPos = new THREE.Vector3(0.24, -0.22, -0.48);
  private gunRecoilZ = 0;
  private gunRecoilRotX = 0;
  private isAimingDownSights = false;

  // Camera orientation
  public cameraYaw: number = 0;
  public cameraPitch: number = 0;

  // Weapon & Ammo
  public currentSkin: WeaponSkin;
  public ammo: number = 2;
  public maxAmmo: number = 2;
  public isReloading: boolean = false;
  public isInfiniteAmmo: boolean = false;
  private reloadTimer: number = 0;
  private flashTimer: number = 0;

  // Game Mode & Level
  public mode: GameMode = 'arcade';
  public currentLevel: CampaignLevel | null = null;
  public difficulty: GameDifficulty = 'normal';
  public isRunning: boolean = false;
  public isPaused: boolean = false;
  public timeRemaining: number = 60;
  private spawnTimer: number = 0;
  private nextSpawnDelay: number = 2.0;

  // Game Stats
  public stats: GameStats = {
    score: 0,
    highScore: 0,
    claysHit: 0,
    claysTotal: 0,
    chickensHit: 0,
    shotsFired: 0,
    combo: 0,
    maxCombo: 0,
    accuracy: 100,
  };

  // Active Entities in 3D scene
  private activeTargets: {
    entity: TargetEntity;
    mesh: THREE.Group;
    chickenParts?: {
      leftWing: THREE.Group;
      rightWing: THREE.Group;
      leftLeg: THREE.Group;
      rightLeg: THREE.Group;
    };
  }[] = [];

  // Particle systems (shattered clay shards and cartoon feathers)
  private particles: {
    mesh: THREE.Mesh;
    vx: number;
    vy: number;
    vz: number;
    rotVx: number;
    rotVy: number;
    life: number;
    maxLife: number;
  }[] = [];

  // Materials pool for particles
  private orangeShardMat: THREE.MeshStandardMaterial;
  private goldenShardMat: THREE.MeshStandardMaterial;
  private featherMat: THREE.MeshStandardMaterial;

  constructor(container: HTMLElement, skin: WeaponSkin, callbacks: GameCallbacks) {
    this.container = container;
    this.currentSkin = skin;
    this.maxAmmo = skin.capacity;
    this.ammo = skin.capacity;
    this.callbacks = callbacks;
    this.clock = new THREE.Clock();

    // 1. Detect software WebGL
    this.isSoftwareGl = (() => {
      const gl = document.createElement('canvas').getContext('webgl2');
      if (!gl) return true;
      const ext = gl.getExtension('WEBGL_debug_renderer_info');
      const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
      const gpu = String(gl.getParameter(param));
      gl.getExtension('WEBGL_lose_context')?.loseContext();
      return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
    })();

    // 2. Initialize Three.js WebGLRenderer
    this.renderer = new THREE.WebGLRenderer({
      antialias: !this.isSoftwareGl,
      powerPreference: 'high-performance',
      stencil: false,
      depth: true,
    });
    this.renderer.outputColorSpace = THREE.SRGBColorSpace;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.15;
    this.renderer.setPixelRatio(this.isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = !this.isSoftwareGl;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.setSize(container.clientWidth, container.clientHeight);
    container.appendChild(this.renderer.domElement);

    // 3. Scene & Camera setup
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x87ceeb); // Clear azure sky
    this.scene.fog = new THREE.FogExp2(0x99ccff, 0.0035); // Horizon atmospheric fade

    this.camera = new THREE.PerspectiveCamera(
      70,
      container.clientWidth / container.clientHeight,
      0.1,
      800
    );
    this.camera.position.set(0, 1.75, 1.2); // Firing line eye height (1.75m)
    this.scene.add(this.camera);

    // Gun container parented to camera for first-person view
    this.gunContainer = new THREE.Group();
    this.camera.add(this.gunContainer);

    // 4. Studio Environment Lighting
    const pmremGenerator = new THREE.PMREMGenerator(this.renderer);
    this.scene.environment = pmremGenerator.fromScene(new RoomEnvironment(), 0.04).texture;
    pmremGenerator.dispose();

    // 5. Sun Key Light & Sky Fill
    const sunLight = new THREE.DirectionalLight(0xfff7e6, 1.8);
    sunLight.position.set(45, 60, 30);
    sunLight.castShadow = !this.isSoftwareGl;
    if (sunLight.shadow) {
      sunLight.shadow.mapSize.width = 1024;
      sunLight.shadow.mapSize.height = 1024;
      sunLight.shadow.camera.near = 10;
      sunLight.shadow.camera.far = 180;
      sunLight.shadow.camera.left = -40;
      sunLight.shadow.camera.right = 40;
      sunLight.shadow.camera.top = 40;
      sunLight.shadow.camera.bottom = -40;
      sunLight.shadow.bias = -0.0005;
      sunLight.shadow.normalBias = 0.02;
    }
    this.scene.add(sunLight);

    const hemiLight = new THREE.HemisphereLight(0xdbeafe, 0x3f5b28, 0.85);
    this.scene.add(hemiLight);

    // 6. Build Ball-Trap Firing Range Environment
    const environmentMesh = createBallTrapEnvironment();
    this.scene.add(environmentMesh);

    // 7. Initialize Materials Pool for Particles
    this.orangeShardMat = new THREE.MeshStandardMaterial({
      color: 0xff5500,
      roughness: 0.7,
      metalness: 0.1,
      side: THREE.DoubleSide,
    });
    this.goldenShardMat = new THREE.MeshStandardMaterial({
      color: 0xffd700,
      roughness: 0.2,
      metalness: 0.9,
      side: THREE.DoubleSide,
    });
    this.featherMat = new THREE.MeshStandardMaterial({
      color: 0xffffff,
      roughness: 0.8,
      side: THREE.DoubleSide,
    });

    // 8. Equip initial Shotgun
    this.setWeaponSkin(skin);

    // 9. Load saved high score from localStorage
    try {
      const saved = localStorage.getItem('crazy_ball_trap_highscore');
      if (saved) {
        this.stats.highScore = parseInt(saved, 10) || 0;
      }
    } catch {
      // ignore
    }

    // 10. Start continuous game loop
    this.loop = this.loop.bind(this);
    this.loop();
  }

  /**
   * Updates weapon skin
   */
  public setWeaponSkin(skin: WeaponSkin) {
    this.currentSkin = skin;
    this.maxAmmo = skin.capacity;
    this.ammo = skin.capacity;

    // Remove existing gun model
    if (this.gunGroup) {
      this.gunContainer.remove(this.gunGroup);
      this.gunGroup = null;
    }

    const { group, muzzleFlash, flashLight } = createShotgunModel(skin);
    this.gunGroup = group;
    this.muzzleFlash = muzzleFlash;
    this.flashLight = flashLight;
    this.gunContainer.add(this.gunGroup);

    this.callbacks.onAmmoUpdate(this.ammo, this.maxAmmo, this.isReloading);
  }

  /**
   * Start a Game Session
   */
  public startGame(mode: GameMode, level?: CampaignLevel, difficulty: GameDifficulty = 'normal') {
    this.mode = mode;
    this.currentLevel = level || null;
    this.difficulty = difficulty;
    this.isRunning = true;
    this.isPaused = false;
    this.isReloading = false;
    this.isInfiniteAmmo = false;

    // Reset stats
    this.stats.score = 0;
    this.stats.claysHit = 0;
    this.stats.claysTotal = 0;
    this.stats.chickensHit = 0;
    this.stats.shotsFired = 0;
    this.stats.combo = 0;
    this.stats.maxCombo = 0;
    this.stats.accuracy = 100;

    this.ammo = this.maxAmmo;
    this.timeRemaining = level ? level.duration : 60;
    this.spawnTimer = 0;
    this.nextSpawnDelay = 1.0;

    // Clear existing entities
    this.clearAllTargets();
    this.clearAllParticles();

    this.callbacks.onScoreUpdate(this.stats);
    this.callbacks.onAmmoUpdate(this.ammo, this.maxAmmo, false);

    // Announce start
    soundEngine.playPullLaunch();
  }

  public pauseGame() {
    this.isPaused = true;
  }

  public resumeGame() {
    this.isPaused = false;
  }

  public toggleAimDownSights(ads?: boolean) {
    this.isAimingDownSights = ads !== undefined ? ads : !this.isAimingDownSights;
  }

  /**
   * Rotate camera from mouse movement or touch swipe
   */
  public handleLookDelta(deltaX: number, deltaY: number, sensitivity: number = 0.0022) {
    if (this.isPaused || !this.isRunning) return;

    this.cameraYaw -= deltaX * sensitivity;
    this.cameraPitch -= deltaY * sensitivity;

    // Clamp angles (cannot look completely behind or into own feet)
    const maxPitch = Math.PI / 3.2; // ~56 degrees up
    const minPitch = -Math.PI / 5.5; // ~-32 degrees down
    this.cameraPitch = Math.max(minPitch, Math.min(maxPitch, this.cameraPitch));

    const maxYaw = Math.PI / 2.2; // ~81 degrees left/right
    this.cameraYaw = Math.max(-maxYaw, Math.min(maxYaw, this.cameraYaw));
  }

  /**
   * Shoot the 12-gauge shotgun!
   */
  public shoot(): boolean {
    if (!this.isRunning || this.isPaused) return false;

    if (this.isReloading) {
      soundEngine.playEmptyClick();
      return false;
    }

    if (this.ammo <= 0 && !this.isInfiniteAmmo) {
      soundEngine.playEmptyClick();
      this.reload();
      return false;
    }

    // Fire weapon!
    if (!this.isInfiniteAmmo) {
      this.ammo--;
    }
    this.stats.shotsFired++;
    this.callbacks.onAmmoUpdate(this.ammo, this.maxAmmo, false);

    // Audio effects
    soundEngine.playShotgun();
    setTimeout(() => soundEngine.playShellEject(), 120);

    // Visual recoil animation
    this.gunRecoilZ = 0.16;
    this.gunRecoilRotX = 0.28;

    // Muzzle flash
    if (this.muzzleFlash && this.flashLight) {
      this.muzzleFlash.visible = true;
      this.flashLight.intensity = 12;
      this.flashTimer = 0.06;
    }

    // Ballistic Shotgun Raycasting with spread cone
    const hitSuccess = this.performShotgunRaycast();

    if (!hitSuccess) {
      // Missed shot resets combo streak
      if (this.stats.combo > 0) {
        this.stats.combo = 0;
        this.callbacks.onScoreUpdate(this.stats);
      }
    }

    // Recalculate accuracy
    const totalHits = this.stats.claysHit + this.stats.chickensHit;
    this.stats.accuracy = Math.min(100, Math.round((totalHits / Math.max(1, this.stats.shotsFired)) * 100));
    this.callbacks.onScoreUpdate(this.stats);

    // Auto-reload if empty
    if (this.ammo === 0 && !this.isInfiniteAmmo) {
      setTimeout(() => {
        if (this.ammo === 0 && !this.isReloading && this.isRunning) {
          this.reload();
        }
      }, 350);
    }

    return true;
  }

  /**
   * Realistic 12-gauge spread raycasting: checks central choke ray + spread tolerance
   */
  private performShotgunRaycast(): boolean {
    // Ray from center of camera
    _vec2.set(0, 0);
    _raycaster.setFromCamera(_vec2, this.camera);

    let closestHitTarget: {
      index: number;
      distance: number;
      target: TargetEntity;
      mesh: THREE.Group;
    } | null = null;

    // Test all active targets
    for (let i = 0; i < this.activeTargets.length; i++) {
      const item = this.activeTargets[i];
      if (item.entity.isHit) continue;

      const targetPos = item.mesh.position;
      const ray = _raycaster.ray;

      // Distance from ray line to target center
      _vec3A.copy(targetPos);
      const distanceAlongRay = ray.distanceToPoint(_vec3A);
      const projPoint = ray.closestPointToPoint(_vec3A, _vec3B);
      const distanceToEye = ray.origin.distanceTo(projPoint);

      // Check if target is in front of camera
      if (_vec3B.sub(ray.origin).dot(ray.direction) > 0) {
        // Shotgun spread expands with distance (choke cone)
        const spreadTolerance = item.entity.radius + Math.max(0.3, distanceToEye * 0.035);

        if (distanceAlongRay <= spreadTolerance) {
          if (!closestHitTarget || distanceToEye < closestHitTarget.distance) {
            closestHitTarget = {
              index: i,
              distance: distanceToEye,
              target: item.entity,
              mesh: item.mesh,
            };
          }
        }
      }
    }

    if (closestHitTarget) {
      this.handleTargetHit(closestHitTarget.index, closestHitTarget.target, closestHitTarget.mesh);
      return true;
    }

    return false;
  }

  /**
   * Handle destruction of target and scoring
   */
  private handleTargetHit(index: number, entity: TargetEntity, mesh: THREE.Group) {
    entity.isHit = true;

    // Increment combo
    this.stats.combo++;
    if (this.stats.combo > this.stats.maxCombo) {
      this.stats.maxCombo = this.stats.combo;
    }

    const comboMultiplier = Math.min(5, 1 + Math.floor(this.stats.combo / 3));
    let basePoints = entity.points;

    // Check hit type
    const isChicken = entity.type.startsWith('chicken');
    if (isChicken) {
      this.stats.chickensHit++;
      soundEngine.playChickenSquawk(entity.type === 'chicken_golden' ? 'golden' : 'hit');

      if (entity.type === 'chicken_golden') {
        // Activate 6 seconds of infinite ammo frenzy!
        this.isInfiniteAmmo = true;
        this.ammo = this.maxAmmo;
        this.callbacks.onAmmoUpdate(this.ammo, this.maxAmmo, false);
        basePoints = 600;

        setTimeout(() => {
          this.isInfiniteAmmo = false;
          this.callbacks.onAmmoUpdate(this.ammo, this.maxAmmo, false);
        }, 6000);
      }

      this.spawnFeatherExplosion(mesh.position, entity.type === 'chicken_golden');
    } else {
      this.stats.claysHit++;
      soundEngine.playClayHit();
      this.spawnClayExplosion(mesh.position, entity.goldenGlow);
    }

    const totalEarned = basePoints * comboMultiplier;
    this.stats.score += totalEarned;

    // Sound chime on combo
    if (this.stats.combo >= 3) {
      soundEngine.playComboSting(this.stats.combo);
    }

    // Trigger HUD hitmarker
    this.callbacks.onHitmarker(isChicken);

    // Floating text notification
    let label = `+${totalEarned}`;
    let color = '#22c55e';
    if (this.stats.combo > 1) {
      label += ` (x${comboMultiplier} COMBO!)`;
      color = '#f59e0b';
    }
    if (entity.type === 'chicken_golden') {
      label = `+${totalEarned} POULET DORÉ INFINI!`;
      color = '#fbbf24';
    } else if (entity.type === 'chicken_rocket') {
      label = `+${totalEarned} CHICKEN ROCKET!`;
      color = '#ef4444';
    }

    // Project 3D position to 2D screen coordinate for floating text
    _vec3A.copy(mesh.position);
    _vec3A.project(this.camera);
    const screenX = ((_vec3A.x + 1) * 0.5) * window.innerWidth;
    const screenY = ((-_vec3A.y + 1) * 0.5) * window.innerHeight;

    this.callbacks.onFloatingText({
      id: Math.random().toString(),
      text: label,
      x: screenX,
      y: screenY,
      color,
      scale: 1.2,
      opacity: 1.0,
    });

    // Remove mesh from scene
    this.scene.remove(mesh);
    this.activeTargets.splice(index, 1);

    // Update stats
    this.callbacks.onScoreUpdate(this.stats);

    // Check if campaign level target completed
    if (this.mode === 'campaign' && this.currentLevel) {
      if (this.stats.claysHit + this.stats.chickensHit >= this.currentLevel.targetCount) {
        this.finishGame(true);
      }
    }
  }

  /**
   * Reload weapon
   */
  public reload() {
    if (this.isReloading || this.ammo >= this.maxAmmo) return;

    this.isReloading = true;
    this.callbacks.onAmmoUpdate(this.ammo, this.maxAmmo, true);
    soundEngine.playReload();

    // Reload duration adjusted by weapon skin
    const reloadDuration = 1100 / this.currentSkin.reloadSpeed;

    setTimeout(() => {
      this.ammo = this.maxAmmo;
      this.isReloading = false;
      this.callbacks.onAmmoUpdate(this.ammo, this.maxAmmo, false);
    }, reloadDuration);
  }

  /**
   * Spawn Clay Pigeon Target
   */
  public spawnClayTarget(golden: boolean = false, bunkerIndex?: number) {
    const bunkers = [
      { x: -16, z: -25 }, // Left
      { x: 0, z: -30 },   // Center
      { x: 16, z: -25 },  // Right
    ];

    const bunker = bunkers[bunkerIndex !== undefined ? bunkerIndex : Math.floor(Math.random() * bunkers.length)];

    const speedMult = (this.currentLevel ? this.currentLevel.claySpeedMultiplier : 1.1) *
      (this.difficulty === 'hardcore' ? 1.3 : this.difficulty === 'easy' ? 0.85 : 1.0);

    // Outward trajectory angle toward center-field
    const angleX = (Math.random() - 0.5) * 14;
    const speedY = (15 + Math.random() * 6) * speedMult;
    const speedZ = (18 + Math.random() * 10) * speedMult;

    const entity: TargetEntity = {
      id: Math.random().toString(),
      type: 'clay',
      position: { x: bunker.x, y: 1.2, z: bunker.z },
      velocity: { x: angleX, y: speedY, z: -speedZ },
      rotation: { x: 0.2, y: 0, z: (Math.random() - 0.5) * 0.4 },
      rotVelocity: { x: (Math.random() - 0.5) * 2, y: 18 + Math.random() * 12, z: (Math.random() - 0.5) * 2 },
      radius: 0.48,
      points: golden ? 300 : 100,
      isHit: false,
      age: 0,
      maxAge: 5.5,
      goldenGlow: golden,
    };

    const mesh = createClayDiscMesh(golden);
    mesh.position.set(entity.position.x, entity.position.y, entity.position.z);
    this.scene.add(mesh);

    this.activeTargets.push({ entity, mesh });
    this.stats.claysTotal++;
    soundEngine.playPullLaunch();
  }

  /**
   * Spawn Comical Cartoon Chicken Target
   */
  public spawnChickenTarget(forcedType?: 'chicken_classic' | 'chicken_rocket' | 'chicken_parachute' | 'chicken_golden') {
    let type = forcedType;
    if (!type) {
      const rand = Math.random();
      if (rand < 0.1) type = 'chicken_golden';
      else if (rand < 0.4) type = 'chicken_rocket';
      else if (rand < 0.65) type = 'chicken_parachute';
      else type = 'chicken_classic';
    }

    const startSide = Math.random() > 0.5 ? 1 : -1;
    let startX = startSide * (25 + Math.random() * 10);
    const startZ = -15 - Math.random() * 35;

    let startY = 0.2;
    let vx = -startSide * (7 + Math.random() * 6);
    let vy = 4 + Math.random() * 5;
    let vz = (Math.random() - 0.5) * 3;
    let maxAge = 7;
    let points = 150;

    if (type === 'chicken_rocket') {
      startY = 4 + Math.random() * 6;
      vx = -startSide * (18 + Math.random() * 8);
      vy = (Math.random() - 0.5) * 3;
      points = 250;
      maxAge = 4.5;
    } else if (type === 'chicken_parachute') {
      startY = 20 + Math.random() * 8;
      startX = (Math.random() - 0.5) * 24;
      vx = (Math.random() - 0.5) * 2;
      vy = -2.5; // gentle descent
      points = 200;
      maxAge = 9;
    } else if (type === 'chicken_golden') {
      points = 500;
      vx *= 1.3;
      vy *= 1.2;
    }

    const entity: TargetEntity = {
      id: Math.random().toString(),
      type,
      position: { x: startX, y: startY, z: startZ },
      velocity: { x: vx, y: vy, z: vz },
      rotation: { x: 0, y: vx < 0 ? -Math.PI / 2 : Math.PI / 2, z: 0 },
      rotVelocity: { x: 0, y: 0, z: 0 },
      radius: 0.6,
      points,
      isHit: false,
      age: 0,
      maxAge,
      flapTime: 0,
    };

    const { group, leftWing, rightWing, leftLeg, rightLeg } = createCartoonChickenModel(type);
    group.position.set(startX, startY, startZ);
    group.rotation.y = entity.rotation.y;
    this.scene.add(group);

    this.activeTargets.push({
      entity,
      mesh: group,
      chickenParts: { leftWing, rightWing, leftLeg, rightLeg },
    });

    soundEngine.playChickenSquawk(type === 'chicken_golden' ? 'golden' : 'cluck');
  }

  /**
   * Explode clay disc into spinning ceramic shards
   */
  private spawnClayExplosion(pos: THREE.Vector3, isGolden = false) {
    const shardCount = 14;
    const mat = isGolden ? this.goldenShardMat : this.orangeShardMat;

    for (let i = 0; i < shardCount; i++) {
      const geo = new THREE.TetrahedronGeometry(0.08 + Math.random() * 0.09, 0);
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.copy(pos);
      this.scene.add(mesh);

      const speed = 4 + Math.random() * 8;
      const phi = Math.random() * Math.PI * 2;
      const theta = Math.random() * Math.PI;

      this.particles.push({
        mesh,
        vx: Math.sin(theta) * Math.cos(phi) * speed,
        vy: (Math.sin(theta) * Math.sin(phi) + 0.5) * speed,
        vz: Math.cos(theta) * speed,
        rotVx: (Math.random() - 0.5) * 15,
        rotVy: (Math.random() - 0.5) * 15,
        life: 0,
        maxLife: 1.4,
      });
    }
  }

  /**
   * Explode chicken into comical fluttering cartoon feathers
   */
  private spawnFeatherExplosion(pos: THREE.Vector3, isGolden = false) {
    const featherCount = 18;
    const mat = isGolden ? this.goldenShardMat : this.featherMat;

    for (let i = 0; i < featherCount; i++) {
      const geo = new THREE.PlaneGeometry(0.12, 0.22);
      const mesh = new THREE.Mesh(geo, mat);
      mesh.position.copy(pos);
      this.scene.add(mesh);

      const speed = 2 + Math.random() * 5;
      this.particles.push({
        mesh,
        vx: (Math.random() - 0.5) * speed,
        vy: 2 + Math.random() * speed,
        vz: (Math.random() - 0.5) * speed,
        rotVx: (Math.random() - 0.5) * 8,
        rotVy: (Math.random() - 0.5) * 8,
        life: 0,
        maxLife: 2.2, // Feathers drift down slowly
      });
    }
  }

  private clearAllTargets() {
    this.activeTargets.forEach((t) => this.scene.remove(t.mesh));
    this.activeTargets = [];
  }

  private clearAllParticles() {
    this.particles.forEach((p) => this.scene.remove(p.mesh));
    this.particles = [];
  }

  /**
   * End of Game
   */
  private finishGame(won: boolean) {
    this.isRunning = false;

    // Check High Score
    if (this.stats.score > this.stats.highScore) {
      this.stats.highScore = this.stats.score;
      try {
        localStorage.setItem('crazy_ball_trap_highscore', this.stats.score.toString());
      } catch {
        // ignore
      }
    }

    this.callbacks.onGameOver(won, this.stats);
  }

  /**
   * Main Simulation & Render Loop
   */
  private loop() {
    const dt = Math.min(this.clock.getDelta(), 0.1);

    if (this.isRunning && !this.isPaused) {
      // 1. Time decrement
      this.timeRemaining -= dt;
      if (this.timeRemaining <= 0) {
        this.timeRemaining = 0;
        this.finishGame(this.mode === 'arcade' || (this.currentLevel ? this.stats.score >= this.currentLevel.requiredScore : true));
      }

      // 2. Spawner Logic
      this.spawnTimer += dt;
      if (this.spawnTimer >= this.nextSpawnDelay) {
        this.spawnTimer = 0;

        // Decide spawn type based on level/mode
        const chickenChance = this.currentLevel ? this.currentLevel.chickenFrequency : 0.38;
        const doubleTrapChance = this.currentLevel ? this.currentLevel.doubleTrapChance : 0.3;

        if (Math.random() < chickenChance) {
          this.spawnChickenTarget();
        } else {
          // Launch clay pigeon
          this.spawnClayTarget(Math.random() < 0.12);

          // Double trap launch!
          if (Math.random() < doubleTrapChance) {
            setTimeout(() => {
              if (this.isRunning && !this.isPaused) {
                this.spawnClayTarget(false, 0); // launch from Left
              }
            }, 250);
          }
        }

        this.nextSpawnDelay = 1.2 + Math.random() * 1.8;
      }

      // 3. Update Targets Kinematics
      const wind = this.currentLevel ? this.currentLevel.windSpeed : 2;

      for (let i = this.activeTargets.length - 1; i >= 0; i--) {
        const item = this.activeTargets[i];
        const { entity, mesh, chickenParts } = item;
        entity.age += dt;

        // Check expiration
        if (entity.age >= entity.maxAge || mesh.position.y < -0.2) {
          this.scene.remove(mesh);
          this.activeTargets.splice(i, 1);
          continue;
        }

        // Apply velocities
        if (entity.type === 'clay') {
          // Ballistic curve: Gravity and Wind
          entity.velocity.y -= 9.8 * dt;
          entity.velocity.x += wind * 0.25 * dt;

          mesh.position.x += entity.velocity.x * dt;
          mesh.position.y += entity.velocity.y * dt;
          mesh.position.z += entity.velocity.z * dt;

          // Rapid disc spin
          mesh.rotation.y += entity.rotVelocity.y * dt;
          mesh.rotation.x = entity.rotation.x + Math.sin(entity.age * 3) * 0.05;
        } else {
          // Chicken motion & hilarious animations
          entity.flapTime = (entity.flapTime || 0) + dt * 14;

          if (entity.type === 'chicken_parachute') {
            // Sway gently back and forth
            mesh.position.y += entity.velocity.y * dt;
            mesh.position.x += Math.sin(entity.flapTime * 0.5) * 1.2 * dt;
            mesh.rotation.z = Math.sin(entity.flapTime * 0.5) * 0.2;
          } else if (entity.type === 'chicken_rocket') {
            // Speed rocket traversal
            mesh.position.x += entity.velocity.x * dt;
            mesh.position.y += entity.velocity.y * dt + Math.sin(entity.flapTime) * 1.5 * dt;
            mesh.position.z += entity.velocity.z * dt;
          } else {
            // Ground runner chicken
            mesh.position.x += entity.velocity.x * dt;
            // Bouncing jumps
            mesh.position.y = Math.max(0.2, Math.abs(Math.sin(entity.flapTime * 0.6)) * 1.8);
          }

          // Animate wings flapping frantically!
          if (chickenParts) {
            const flapAngle = Math.sin(entity.flapTime) * 0.7;
            chickenParts.leftWing.rotation.z = flapAngle;
            chickenParts.rightWing.rotation.z = -flapAngle;

            // Animate running legs
            const legWalk = Math.sin(entity.flapTime * 0.8) * 0.6;
            chickenParts.leftLeg.rotation.x = legWalk;
            chickenParts.rightLeg.rotation.x = -legWalk;
          }
        }
      }

      // 4. Update Particle Physics
      for (let i = this.particles.length - 1; i >= 0; i--) {
        const p = this.particles[i];
        p.life += dt;

        if (p.life >= p.maxLife) {
          this.scene.remove(p.mesh);
          this.particles.splice(i, 1);
          continue;
        }

        // Particle gravity & air resistance
        p.vy -= (p.maxLife > 2 ? 1.5 : 9.8) * dt; // feathers drop slower
        p.mesh.position.x += p.vx * dt;
        p.mesh.position.y += p.vy * dt;
        p.mesh.position.z += p.vz * dt;

        p.mesh.rotation.x += p.rotVx * dt;
        p.mesh.rotation.y += p.rotVy * dt;

        const progress = p.life / p.maxLife;
        const scale = 1 - progress * 0.5;
        p.mesh.scale.set(scale, scale, scale);
      }
    }

    // 5. Update Camera Angles & Aim Down Sights (ADS)
    this.camera.rotation.set(0, 0, 0);
    this.camera.rotation.y = this.cameraYaw;
    this.camera.rotation.x = this.cameraPitch;

    // Smooth ADS FOV zoom
    const targetFov = this.isAimingDownSights ? 50 : 70;
    this.camera.fov = THREE.MathUtils.damp(this.camera.fov, targetFov, 12, dt);
    this.camera.updateProjectionMatrix();

    // 6. Gun Positioning & Recoil Recovery
    if (this.gunGroup) {
      const targetPos = this.isAimingDownSights ? this.gunAdsPos : this.gunRestPos;
      this.gunTargetPos.copy(targetPos);

      // Damp recoil back to rest
      this.gunRecoilZ = THREE.MathUtils.damp(this.gunRecoilZ, 0, 14, dt);
      this.gunRecoilRotX = THREE.MathUtils.damp(this.gunRecoilRotX, 0, 16, dt);

      this.gunCurrentPos.x = THREE.MathUtils.damp(this.gunCurrentPos.x, this.gunTargetPos.x, 15, dt);
      this.gunCurrentPos.y = THREE.MathUtils.damp(this.gunCurrentPos.y, this.gunTargetPos.y, 15, dt);
      this.gunCurrentPos.z = THREE.MathUtils.damp(this.gunCurrentPos.z, this.gunTargetPos.z + this.gunRecoilZ, 20, dt);

      this.gunGroup.position.copy(this.gunCurrentPos);
      this.gunGroup.rotation.x = (this.isAimingDownSights ? 0 : 0.03) + this.gunRecoilRotX;
      this.gunGroup.rotation.y = this.isAimingDownSights ? 0 : -0.04;
    }

    // 7. Muzzle Flash timeout
    if (this.flashTimer > 0) {
      this.flashTimer -= dt;
      if (this.flashTimer <= 0) {
        if (this.muzzleFlash) this.muzzleFlash.visible = false;
        if (this.flashLight) this.flashLight.intensity = 0;
      }
    }

    // 8. Render Frame
    this.renderer.render(this.scene, this.camera);

    this.animFrameId = requestAnimationFrame(this.loop);
  }

  /**
   * Resize handler
   */
  public handleResize() {
    if (!this.container || !this.renderer || !this.camera) return;
    const width = this.container.clientWidth;
    const height = this.container.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  }

  /**
   * Cleanup resources on unmount
   */
  public dispose() {
    cancelAnimationFrame(this.animFrameId);
    this.clearAllTargets();
    this.clearAllParticles();

    this.orangeShardMat.dispose();
    this.goldenShardMat.dispose();
    this.featherMat.dispose();

    if (this.renderer.domElement && this.renderer.domElement.parentNode) {
      this.renderer.domElement.parentNode.removeChild(this.renderer.domElement);
    }
    this.renderer.dispose();
  }
}
