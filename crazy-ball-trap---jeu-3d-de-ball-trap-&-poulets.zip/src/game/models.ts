/**
 * Procedural 3D Models for CRAZY BALL TRAP
 * Built with composite 3-12 part THREE.Group meshes - Zero 404 dependencies
 */
import * as THREE from 'three';
import { WeaponSkin } from './types';

/**
 * Creates procedural procedural textures using 2D canvas
 */
export function createWoodTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  
  // Base rich walnut wood
  ctx.fillStyle = '#4a2511';
  ctx.fillRect(0, 0, 512, 512);
  
  // Wood grain stripes
  for (let i = 0; i < 400; i++) {
    const y = Math.random() * 512;
    const height = Math.random() * 3 + 1;
    ctx.fillStyle = Math.random() > 0.5 ? '#361809' : '#5c3118';
    ctx.globalAlpha = Math.random() * 0.35 + 0.1;
    ctx.beginPath();
    ctx.ellipse(256, y, 260, height, (Math.random() - 0.5) * 0.1, 0, Math.PI * 2);
    ctx.fill();
  }
  ctx.globalAlpha = 1.0;

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.wrapS = THREE.RepeatWrapping;
  texture.wrapT = THREE.RepeatWrapping;
  return texture;
}

export function createClayTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;

  // High-vis fluorescent orange
  ctx.fillStyle = '#ff4d00';
  ctx.fillRect(0, 0, 256, 256);

  // Concentric ridges typical of Olympic competition clays
  const center = 128;
  for (let r = 20; r < 120; r += 16) {
    ctx.strokeStyle = '#e03a00';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.arc(center, center, r, 0, Math.PI * 2);
    ctx.stroke();

    ctx.strokeStyle = '#ff7b33';
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.arc(center, center, r + 4, 0, Math.PI * 2);
    ctx.stroke();
  }

  // White inner rim ring
  ctx.strokeStyle = '#ffffff';
  ctx.lineWidth = 5;
  ctx.beginPath();
  ctx.arc(center, center, 75, 0, Math.PI * 2);
  ctx.stroke();

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

/**
 * Creates the Hero First-Person 12-Gauge Shotgun (Superposé Beretta style)
 */
export function createShotgunModel(skin: WeaponSkin): {
  group: THREE.Group;
  muzzleFlash: THREE.Group;
  flashLight: THREE.PointLight;
  leftWing?: THREE.Mesh;
  rightWing?: THREE.Mesh;
} {
  const gunGroup = new THREE.Group();

  // Materials based on skin
  const woodTexture = createWoodTexture();
  const stockMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(skin.stockColor),
    map: woodTexture,
    roughness: 0.35,
    metalness: 0.1,
  });

  const barrelMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(skin.barrelColor),
    roughness: 0.18,
    metalness: 0.88,
  });

  const receiverMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(skin.receiverColor),
    roughness: 0.22,
    metalness: 0.85,
  });

  const rubberMat = new THREE.MeshStandardMaterial({
    color: 0x1a1a1a,
    roughness: 0.85,
    metalness: 0.05,
  });

  const goldAccentMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(skin.accentColor),
    roughness: 0.2,
    metalness: 0.95,
  });

  // 1. Dual Over-and-Under Barrels (Length ~ 0.8m)
  const barrelGeo = new THREE.CylinderGeometry(0.016, 0.016, 0.78, 24);
  barrelGeo.rotateX(Math.PI / 2); // point along -Z

  const topBarrel = new THREE.Mesh(barrelGeo, barrelMat);
  topBarrel.position.set(0, 0.018, -0.42);
  topBarrel.castShadow = true;
  gunGroup.add(topBarrel);

  const bottomBarrel = new THREE.Mesh(barrelGeo, barrelMat);
  bottomBarrel.position.set(0, -0.012, -0.42);
  bottomBarrel.castShadow = true;
  gunGroup.add(bottomBarrel);

  // Ventilated top rib
  const ribGeo = new THREE.BoxGeometry(0.008, 0.006, 0.76);
  const topRib = new THREE.Mesh(ribGeo, barrelMat);
  topRib.position.set(0, 0.038, -0.42);
  gunGroup.add(topRib);

  // Front brass bead sight
  const beadGeo = new THREE.SphereGeometry(0.004, 12, 12);
  const bead = new THREE.Mesh(beadGeo, goldAccentMat);
  bead.position.set(0, 0.043, -0.79);
  gunGroup.add(bead);

  // 2. Fore-end wood grip beneath barrels
  const foreEndGeo = new THREE.CylinderGeometry(0.024, 0.026, 0.32, 16, 1, false, 0, Math.PI);
  foreEndGeo.rotateX(Math.PI / 2);
  foreEndGeo.rotateZ(Math.PI);
  const foreEnd = new THREE.Mesh(foreEndGeo, stockMat);
  foreEnd.position.set(0, -0.016, -0.22);
  foreEnd.castShadow = true;
  gunGroup.add(foreEnd);

  // 3. Steel Receiver / Action block
  const receiverGeo = new THREE.BoxGeometry(0.044, 0.068, 0.16);
  const receiver = new THREE.Mesh(receiverGeo, receiverMat);
  receiver.position.set(0, 0.005, 0.02);
  receiver.castShadow = true;
  gunGroup.add(receiver);

  // Top break lever
  const leverGeo = new THREE.BoxGeometry(0.01, 0.016, 0.04);
  const lever = new THREE.Mesh(leverGeo, goldAccentMat);
  lever.position.set(0.004, 0.042, 0.06);
  gunGroup.add(lever);

  // Trigger guard and trigger
  const guardGeo = new THREE.TorusGeometry(0.022, 0.003, 8, 20, Math.PI);
  guardGeo.rotateY(Math.PI / 2);
  guardGeo.rotateZ(-Math.PI / 6);
  const guard = new THREE.Mesh(guardGeo, receiverMat);
  guard.position.set(0, -0.042, 0.04);
  gunGroup.add(guard);

  const triggerGeo = new THREE.BoxGeometry(0.004, 0.016, 0.006);
  const trigger = new THREE.Mesh(triggerGeo, goldAccentMat);
  trigger.position.set(0, -0.038, 0.035);
  trigger.rotation.x = -0.3;
  gunGroup.add(trigger);

  // 4. Ergonomic Walnut Buttstock with comb & grip
  const stockGripGeo = new THREE.BoxGeometry(0.038, 0.065, 0.22);
  const stockGrip = new THREE.Mesh(stockGripGeo, stockMat);
  stockGrip.position.set(0, -0.035, 0.18);
  stockGrip.rotation.x = -0.15;
  stockGrip.castShadow = true;
  gunGroup.add(stockGrip);

  const buttStockGeo = new THREE.BoxGeometry(0.04, 0.11, 0.22);
  const buttStock = new THREE.Mesh(buttStockGeo, stockMat);
  buttStock.position.set(0, -0.065, 0.35);
  buttStock.rotation.x = -0.12;
  buttStock.castShadow = true;
  gunGroup.add(buttStock);

  // Rubber recoil pad
  const padGeo = new THREE.BoxGeometry(0.042, 0.12, 0.025);
  const pad = new THREE.Mesh(padGeo, rubberMat);
  pad.position.set(0, -0.076, 0.465);
  pad.rotation.x = -0.12;
  gunGroup.add(pad);

  // 5. Muzzle Flash & Flash PointLight
  const muzzleFlash = new THREE.Group();
  muzzleFlash.position.set(0, 0.018, -0.85);

  const flashGeo = new THREE.OctahedronGeometry(0.08, 1);
  const flashMat = new THREE.MeshBasicMaterial({
    color: 0xffe680,
    transparent: true,
    opacity: 0.9,
  });
  const flashCore = new THREE.Mesh(flashGeo, flashMat);
  flashCore.scale.set(1, 1, 2.5);
  muzzleFlash.add(flashCore);

  const flashLight = new THREE.PointLight(0xff9900, 0, 15);
  flashLight.position.set(0, 0.018, -0.85);
  gunGroup.add(flashLight);

  muzzleFlash.visible = false;
  gunGroup.add(muzzleFlash);

  // Position gun realistically in first-person view (bottom right)
  gunGroup.position.set(0.24, -0.22, -0.48);
  gunGroup.rotation.set(0.03, -0.04, 0);

  return { group: gunGroup, muzzleFlash, flashLight };
}

/**
 * Creates an Olympic style Clay Pigeon Disc (Plateau de ball-trap)
 */
export function createClayDiscMesh(isGolden = false): THREE.Group {
  const clayGroup = new THREE.Group();

  const clayTex = createClayTexture();
  const clayMat = new THREE.MeshStandardMaterial({
    color: isGolden ? 0xffcc00 : 0xff4d00,
    map: isGolden ? undefined : clayTex,
    roughness: isGolden ? 0.2 : 0.65,
    metalness: isGolden ? 0.85 : 0.08,
  });

  // Aerodynamic stepped disc geometry
  // 1. Center raised dome
  const domeGeo = new THREE.CylinderGeometry(0.18, 0.24, 0.03, 32);
  const dome = new THREE.Mesh(domeGeo, clayMat);
  dome.castShadow = true;
  clayGroup.add(dome);

  // 2. Outer aerodynamic stepped skirt
  const skirtGeo = new THREE.CylinderGeometry(0.24, 0.30, 0.02, 32);
  skirtGeo.translate(0, -0.02, 0);
  const skirt = new THREE.Mesh(skirtGeo, clayMat);
  skirt.castShadow = true;
  clayGroup.add(skirt);

  // 3. Bottom concave recess
  const bottomRecessGeo = new THREE.CylinderGeometry(0.16, 0.16, 0.015, 24);
  bottomRecessGeo.translate(0, -0.025, 0);
  const recessMat = new THREE.MeshStandardMaterial({
    color: isGolden ? 0xd4af37 : 0xcc3300,
    roughness: 0.8,
  });
  const bottom = new THREE.Mesh(bottomRecessGeo, recessMat);
  clayGroup.add(bottom);

  if (isGolden) {
    // Add golden halo glow ring
    const haloGeo = new THREE.TorusGeometry(0.34, 0.015, 8, 32);
    haloGeo.rotateX(Math.PI / 2);
    const haloMat = new THREE.MeshBasicMaterial({
      color: 0xfff066,
      transparent: true,
      opacity: 0.8,
    });
    const halo = new THREE.Mesh(haloGeo, haloMat);
    clayGroup.add(halo);
  }

  return clayGroup;
}

/**
 * Creates the Hilarious Cartoon Chicken Model
 * (3-12 parts: body, head, comb, wattle, beak, googly eyes, flapping wings, legs, feet)
 */
export function createCartoonChickenModel(type: 'chicken_classic' | 'chicken_rocket' | 'chicken_parachute' | 'chicken_golden'): {
  group: THREE.Group;
  leftWing: THREE.Group;
  rightWing: THREE.Group;
  leftLeg: THREE.Group;
  rightLeg: THREE.Group;
} {
  const chickenGroup = new THREE.Group();
  const isGolden = type === 'chicken_golden';

  // Plumage Material
  const bodyMat = new THREE.MeshStandardMaterial({
    color: isGolden ? 0xffd700 : 0xfbfbfb,
    roughness: isGolden ? 0.25 : 0.7,
    metalness: isGolden ? 0.75 : 0.05,
  });

  const combMat = new THREE.MeshStandardMaterial({
    color: isGolden ? 0xffaa00 : 0xd81b24,
    roughness: 0.5,
    metalness: 0.1,
  });

  const beakMat = new THREE.MeshStandardMaterial({
    color: 0xf59e0b,
    roughness: 0.4,
    metalness: 0.2,
  });

  const eyeWhiteMat = new THREE.MeshBasicMaterial({ color: 0xffffff });
  const pupilMat = new THREE.MeshBasicMaterial({ color: 0x111111 });

  // 1. Plump egg body
  const bodyGeo = new THREE.SphereGeometry(0.38, 20, 20);
  bodyGeo.scale(1.0, 1.25, 1.1);
  const body = new THREE.Mesh(bodyGeo, bodyMat);
  body.position.set(0, 0.46, 0);
  body.castShadow = true;
  chickenGroup.add(body);

  // 2. Head with rounded neck
  const headGeo = new THREE.SphereGeometry(0.24, 16, 16);
  const head = new THREE.Mesh(headGeo, bodyMat);
  head.position.set(0, 0.88, 0.16);
  head.castShadow = true;
  chickenGroup.add(head);

  // 3. Red Comb (3 bumps)
  const combGroup = new THREE.Group();
  combGroup.position.set(0, 1.08, 0.14);
  [-0.06, 0, 0.07].forEach((zOff, i) => {
    const bumpGeo = new THREE.SphereGeometry(0.06 + i * 0.01, 10, 10);
    bumpGeo.scale(0.35, 1.4, 1.0);
    const bump = new THREE.Mesh(bumpGeo, combMat);
    bump.position.set(0, (i === 1 ? 0.04 : 0), zOff);
    combGroup.add(bump);
  });
  chickenGroup.add(combGroup);

  // 4. Red Wattle beneath chin
  const wattleGeo = new THREE.SphereGeometry(0.06, 10, 10);
  wattleGeo.scale(0.4, 1.5, 0.8);
  const wattle = new THREE.Mesh(wattleGeo, combMat);
  wattle.position.set(0, 0.74, 0.34);
  chickenGroup.add(wattle);

  // 5. Beak
  const beakGeo = new THREE.ConeGeometry(0.08, 0.18, 8);
  beakGeo.rotateX(Math.PI / 2);
  const beak = new THREE.Mesh(beakGeo, beakMat);
  beak.position.set(0, 0.84, 0.42);
  chickenGroup.add(beak);

  // 6. Googly Eyes (Big & Hilarious)
  [-0.12, 0.12].forEach((xOff) => {
    const eyeGeo = new THREE.SphereGeometry(0.09, 12, 12);
    const eye = new THREE.Mesh(eyeGeo, eyeWhiteMat);
    eye.position.set(xOff, 0.94, 0.31);

    const pupilGeo = new THREE.SphereGeometry(0.045, 10, 10);
    const pupil = new THREE.Mesh(pupilGeo, pupilMat);
    pupil.position.set(0, 0.01, 0.065);
    eye.add(pupil);

    chickenGroup.add(eye);
  });

  // 7. Flapping Wings (Left & Right)
  const leftWing = new THREE.Group();
  leftWing.position.set(0.34, 0.52, 0);
  const wingGeo = new THREE.BoxGeometry(0.08, 0.28, 0.32);
  const wingMeshL = new THREE.Mesh(wingGeo, bodyMat);
  wingMeshL.position.set(0.06, -0.06, 0);
  wingMeshL.castShadow = true;
  leftWing.add(wingMeshL);
  chickenGroup.add(leftWing);

  const rightWing = new THREE.Group();
  rightWing.position.set(-0.34, 0.52, 0);
  const wingMeshR = new THREE.Mesh(wingGeo, bodyMat);
  wingMeshR.position.set(-0.06, -0.06, 0);
  wingMeshR.castShadow = true;
  rightWing.add(wingMeshR);
  chickenGroup.add(rightWing);

  // 8. Chicken Legs
  const legGeo = new THREE.CylinderGeometry(0.02, 0.02, 0.28, 8);
  const footGeo = new THREE.BoxGeometry(0.12, 0.02, 0.18);
  footGeo.translate(0, -0.14, 0.04);

  const leftLeg = new THREE.Group();
  leftLeg.position.set(0.14, 0.18, 0);
  const legMeshL = new THREE.Mesh(legGeo, beakMat);
  const footMeshL = new THREE.Mesh(footGeo, beakMat);
  leftLeg.add(legMeshL, footMeshL);
  chickenGroup.add(leftLeg);

  const rightLeg = new THREE.Group();
  rightLeg.position.set(-0.14, 0.18, 0);
  const legMeshR = new THREE.Mesh(legGeo, beakMat);
  const footMeshR = new THREE.Mesh(footGeo, beakMat);
  rightLeg.add(legMeshR, footMeshR);
  chickenGroup.add(rightLeg);

  // Special Variants:
  if (type === 'chicken_rocket') {
    // Twin Acme style Cartoon Jetpack on back
    const jetMat = new THREE.MeshStandardMaterial({ color: 0xef4444, metalness: 0.6, roughness: 0.3 });
    const coneMat = new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: 0.5, roughness: 0.4 });
    const jetpack = new THREE.Group();
    jetpack.position.set(0, 0.52, -0.36);

    [-0.14, 0.14].forEach((xOff) => {
      const rocketBody = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.38, 12), jetMat);
      rocketBody.position.x = xOff;
      const noseCone = new THREE.Mesh(new THREE.ConeGeometry(0.07, 0.15, 12), coneMat);
      noseCone.position.set(xOff, 0.26, 0);
      jetpack.add(rocketBody, noseCone);
    });
    chickenGroup.add(jetpack);
  } else if (type === 'chicken_parachute') {
    // Parachute canopy above chicken
    const canopyMat = new THREE.MeshStandardMaterial({ color: 0x3b82f6, roughness: 0.6 });
    const canopy = new THREE.Mesh(new THREE.SphereGeometry(0.65, 16, 12, 0, Math.PI * 2, 0, Math.PI / 2), canopyMat);
    canopy.position.set(0, 1.85, 0);
    canopy.rotation.x = Math.PI;

    // String lines
    const lineMat = new THREE.LineBasicMaterial({ color: 0xffffff });
    [-0.4, 0.4].forEach((xOff) => {
      [-0.4, 0.4].forEach((zOff) => {
        const points = [
          new THREE.Vector3(xOff, 1.8, zOff),
          new THREE.Vector3(xOff * 0.3, 0.8, zOff * 0.3),
        ];
        const lineGeo = new THREE.BufferGeometry().setFromPoints(points);
        const line = new THREE.Line(lineGeo, lineMat);
        chickenGroup.add(line);
      });
    });
    chickenGroup.add(canopy);
  } else if (isGolden) {
    // Sparkle crown
    const crownMat = new THREE.MeshStandardMaterial({ color: 0xfff066, metalness: 0.95, roughness: 0.1 });
    const crown = new THREE.Mesh(new THREE.CylinderGeometry(0.12, 0.08, 0.1, 7), crownMat);
    crown.position.set(0, 1.22, 0.14);
    chickenGroup.add(crown);
  }

  return { group: chickenGroup, leftWing, rightWing, leftLeg, rightLeg };
}

/**
 * Creates the Ball-Trap Firing Range Environment
 */
export function createBallTrapEnvironment(): THREE.Group {
  const env = new THREE.Group();

  // 1. Vast Terrain (Grass Field)
  const fieldGeo = new THREE.PlaneGeometry(600, 600, 64, 64);
  fieldGeo.rotateX(-Math.PI / 2);

  // Apply subtle rolling waves to vertices
  const pos = fieldGeo.attributes.position;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i);
    const z = pos.getZ(i);
    // Flat around the shooting station (z > -20)
    if (z < -30) {
      const dist = Math.abs(z);
      const wave = Math.sin(x * 0.03) * Math.cos(z * 0.02) * (dist * 0.04);
      pos.setY(i, wave);
    }
  }
  fieldGeo.computeVertexNormals();

  const grassMat = new THREE.MeshStandardMaterial({
    color: 0x486b32,
    roughness: 0.85,
    metalness: 0.05,
  });
  const field = new THREE.Mesh(fieldGeo, grassMat);
  field.receiveShadow = true;
  env.add(field);

  // 2. Stand de tir (Wooden Firing Deck / Pas de Tir)
  const deckMat = new THREE.MeshStandardMaterial({
    color: 0x8b5a2b,
    roughness: 0.7,
    metalness: 0.1,
  });
  const deckGeo = new THREE.BoxGeometry(10, 0.35, 6);
  const deck = new THREE.Mesh(deckGeo, deckMat);
  deck.position.set(0, 0.18, 0);
  deck.receiveShadow = true;
  deck.castShadow = true;
  env.add(deck);

  // Firing stations pads (5 stations numbered 1 to 5)
  const padMat = new THREE.MeshStandardMaterial({
    color: 0x333333,
    roughness: 0.9,
  });
  for (let i = -2; i <= 2; i++) {
    const stationPad = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.05, 1.2), padMat);
    stationPad.position.set(i * 1.8, 0.38, 0.8);
    stationPad.receiveShadow = true;
    env.add(stationPad);
  }

  // Safety railings around deck
  const railMat = new THREE.MeshStandardMaterial({ color: 0x5a3d28, roughness: 0.6 });
  const backRail = new THREE.Mesh(new THREE.BoxGeometry(10.2, 0.9, 0.08), railMat);
  backRail.position.set(0, 0.8, 3.0);
  backRail.castShadow = true;
  env.add(backRail);

  const leftRail = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.9, 6.0), railMat);
  leftRail.position.set(-5.0, 0.8, 0);
  leftRail.castShadow = true;
  env.add(leftRail);

  const rightRail = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.9, 6.0), railMat);
  rightRail.position.set(5.0, 0.8, 0);
  rightRail.castShadow = true;
  env.add(rightRail);

  // 3. Fosse de Ball-Trap (3 Trap Houses / Lanceurs: Gauche, Centre, Droite)
  const bunkerMat = new THREE.MeshStandardMaterial({ color: 0x2e5c38, roughness: 0.6 }); // Green army/sport bunker
  const roofMat = new THREE.MeshStandardMaterial({ color: 0x1d3d24, roughness: 0.5 });
  const slotMat = new THREE.MeshBasicMaterial({ color: 0x050505 });

  const trapPositions = [
    { x: -16, z: -25 }, // Left
    { x: 0, z: -30 },   // Center (main Olympic trench)
    { x: 16, z: -25 },  // Right
  ];

  trapPositions.forEach((pos, idx) => {
    const trapGroup = new THREE.Group();
    trapGroup.position.set(pos.x, 0, pos.z);

    const bunker = new THREE.Mesh(new THREE.BoxGeometry(4.2, 1.4, 2.6), bunkerMat);
    bunker.position.set(0, 0.7, 0);
    bunker.castShadow = true;
    bunker.receiveShadow = true;
    trapGroup.add(bunker);

    const roof = new THREE.Mesh(new THREE.ConeGeometry(3.2, 0.8, 4), roofMat);
    roof.position.set(0, 1.7, 0);
    roof.rotation.y = Math.PI / 4;
    roof.scale.set(1.1, 1, 0.75);
    trapGroup.add(roof);

    // Ejection opening slot where clays fly out
    const slot = new THREE.Mesh(new THREE.BoxGeometry(2.0, 0.35, 0.1), slotMat);
    slot.position.set(0, 0.85, 1.31);
    trapGroup.add(slot);

    // Small Olympic flag on bunker
    const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 2.2), new THREE.MeshStandardMaterial({ color: 0xdddddd }));
    pole.position.set(1.8, 1.5, 0);
    const flagGeo = new THREE.PlaneGeometry(0.6, 0.4);
    const flagMat = new THREE.MeshBasicMaterial({ color: idx === 1 ? 0xff4444 : 0x3b82f6, side: THREE.DoubleSide });
    const flag = new THREE.Mesh(flagGeo, flagMat);
    flag.position.set(2.1, 2.3, 0);
    trapGroup.add(pole, flag);

    env.add(trapGroup);
  });

  // 4. Distance Markers (15m, 25m, 40m, 50m)
  [15, 25, 40, 50].forEach((dist) => {
    [-18, 18].forEach((sideX) => {
      const markerGroup = new THREE.Group();
      markerGroup.position.set(sideX, 0, -dist);

      const signPost = new THREE.Mesh(new THREE.CylinderGeometry(0.04, 0.04, 1.6), railMat);
      signPost.position.y = 0.8;
      const signBoard = new THREE.Mesh(new THREE.BoxGeometry(0.9, 0.5, 0.06), new THREE.MeshStandardMaterial({ color: 0xf3f4f6 }));
      signBoard.position.y = 1.35;
      markerGroup.add(signPost, signBoard);
      env.add(markerGroup);
    });
  });

  // 5. Pine Trees & Birch Trees around range perimeter
  const pineTrunkMat = new THREE.MeshStandardMaterial({ color: 0x3d2817, roughness: 0.9 });
  const pineFoliageMat1 = new THREE.MeshStandardMaterial({ color: 0x1f3b20, roughness: 0.8 });
  const pineFoliageMat2 = new THREE.MeshStandardMaterial({ color: 0x2b4c2c, roughness: 0.8 });

  // Generate 60 procedural trees on sides and far background
  for (let i = 0; i < 70; i++) {
    const treeGroup = new THREE.Group();

    // Place outside the line of fire
    let treeX = (Math.random() - 0.5) * 280;
    let treeZ = -40 - Math.random() * 200;
    if (Math.abs(treeX) < 28 && treeZ > -100) {
      // Move outwards away from central shooting corridor
      treeX += treeX >= 0 ? 30 : -30;
    }

    const scale = 0.75 + Math.random() * 0.6;
    treeGroup.position.set(treeX, 0, treeZ);
    treeGroup.scale.set(scale, scale, scale);

    // Trunk
    const trunk = new THREE.Mesh(new THREE.CylinderGeometry(0.2, 0.35, 3.5, 8), pineTrunkMat);
    trunk.position.y = 1.75;
    trunk.castShadow = true;
    treeGroup.add(trunk);

    // 3 tiered foliage cones
    const foliageMat = i % 2 === 0 ? pineFoliageMat1 : pineFoliageMat2;
    [3.2, 4.6, 5.8].forEach((yPos, layer) => {
      const cone = new THREE.Mesh(
        new THREE.ConeGeometry(2.2 - layer * 0.45, 2.2, 8),
        foliageMat
      );
      cone.position.y = yPos;
      cone.castShadow = true;
      treeGroup.add(cone);
    });

    env.add(treeGroup);
  }

  // 6. Mountain Backdrop in horizon
  const mountainGeo = new THREE.ConeGeometry(80, 75, 5);
  mountainGeo.rotateY(Math.PI / 4);
  const mountainMat = new THREE.MeshStandardMaterial({
    color: 0x475569,
    roughness: 0.95,
  });

  const mountainPositions = [
    { x: -140, z: -320, s: 1.2 },
    { x: -50, z: -360, s: 1.5 },
    { x: 60, z: -340, s: 1.4 },
    { x: 160, z: -310, s: 1.1 },
  ];

  mountainPositions.forEach((m) => {
    const mountain = new THREE.Mesh(mountainGeo, mountainMat);
    mountain.position.set(m.x, 25 * m.s, m.z);
    mountain.scale.set(m.s, m.s, m.s);
    env.add(mountain);

    // Snow cap peak
    const snowCap = new THREE.Mesh(
      new THREE.ConeGeometry(28 * m.s, 24 * m.s, 5),
      new THREE.MeshStandardMaterial({ color: 0xf1f5f9, roughness: 0.7 })
    );
    snowCap.position.set(m.x, (25 + 46) * m.s, m.z);
    env.add(snowCap);
  });

  return env;
}
