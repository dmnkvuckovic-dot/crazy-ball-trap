/**
 * CRAZY BALL TRAP - Main Application Entry
 * Switches seamlessly between the professional website showcase portal and the 3D first-person game engine
 */
import React, { useState, useEffect } from 'react';
import { GameCanvas } from './game/GameCanvas';
import { WebsiteHeader } from './components/WebsiteHeader';
import { WebsiteHero } from './components/WebsiteHero';
import { FeaturesSection } from './components/FeaturesSection';
import { RulesAndGuidesSection } from './components/RulesAndGuidesSection';
import { Footer } from './components/Footer';
import { ArmoryModal } from './components/ArmoryModal';
import { LevelSelectorModal } from './components/LevelSelectorModal';
import { ExportGuideModal } from './components/ExportGuideModal';
import { CampaignLevel, GameDifficulty, GameMode, WeaponSkin } from './game/types';
import { WEAPON_SKINS } from './game/weapons';
import { CAMPAIGN_LEVELS } from './game/levels';
import { soundEngine } from './game/audio';

export default function App() {
  const [view, setView] = useState<'website' | 'game'>('website');

  // Game configuration
  const [currentSkin, setCurrentSkin] = useState<WeaponSkin>(() => {
    try {
      const saved = localStorage.getItem('crazy_ball_trap_skin');
      if (saved) {
        const found = WEAPON_SKINS.find((s) => s.id === saved);
        if (found) return found;
      }
    } catch {
      // ignore
    }
    return WEAPON_SKINS[0];
  });

  const [gameMode, setGameMode] = useState<GameMode>('campaign');
  const [currentLevel, setCurrentLevel] = useState<CampaignLevel>(CAMPAIGN_LEVELS[0]);
  const [difficulty, setDifficulty] = useState<GameDifficulty>('normal');
  const [highScore, setHighScore] = useState<number>(0);

  // Modals state
  const [showArmory, setShowArmory] = useState(false);
  const [showLevels, setShowLevels] = useState(false);
  const [showExportGuide, setShowExportGuide] = useState(false);

  // Load high score
  useEffect(() => {
    try {
      const savedScore = localStorage.getItem('crazy_ball_trap_highscore');
      if (savedScore) {
        setHighScore(parseInt(savedScore, 10) || 0);
      }
    } catch {
      // ignore
    }
  }, [view]);

  const handleSelectSkin = (skin: WeaponSkin) => {
    setCurrentSkin(skin);
    try {
      localStorage.setItem('crazy_ball_trap_skin', skin.id);
    } catch {
      // ignore
    }
  };

  const handleStartGame = (mode: GameMode = 'campaign', level?: CampaignLevel, diff: GameDifficulty = 'normal') => {
    soundEngine.playUiClick();
    setGameMode(mode);
    if (level) {
      setCurrentLevel(level);
    }
    setDifficulty(diff);
    setShowLevels(false);
    setView('game');
  };

  const handleExitGame = () => {
    soundEngine.playUiClick();
    setView('website');
    // Refresh high score
    try {
      const savedScore = localStorage.getItem('crazy_ball_trap_highscore');
      if (savedScore) {
        setHighScore(parseInt(savedScore, 10) || 0);
      }
    } catch {
      // ignore
    }
  };

  const handleScrollToSection = (sectionId: string) => {
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col selection:bg-amber-500 selection:text-slate-950">
      {view === 'game' ? (
        // 3D Fullscreen Game View
        <main className="fixed inset-0 w-full h-full z-50 overflow-hidden">
          <GameCanvas
            mode={gameMode}
            level={gameMode === 'campaign' ? currentLevel : undefined}
            difficulty={difficulty}
            weaponSkin={currentSkin}
            onExit={handleExitGame}
          />
        </main>
      ) : (
        // Professional Website Portal Showcase
        <div className="flex-1 flex flex-col">
          <WebsiteHeader
            onPlayClick={() => handleStartGame('campaign', CAMPAIGN_LEVELS[0])}
            onArmoryClick={() => setShowArmory(true)}
            onLevelsClick={() => setShowLevels(true)}
            onExportClick={() => setShowExportGuide(true)}
            onScrollToSection={handleScrollToSection}
          />

          <main className="flex-1">
            <WebsiteHero
              highScore={highScore}
              onPlayClick={() => handleStartGame('campaign', CAMPAIGN_LEVELS[0])}
              onLevelsClick={() => setShowLevels(true)}
              onArmoryClick={() => setShowArmory(true)}
              onExportClick={() => setShowExportGuide(true)}
            />

            <FeaturesSection
              onPlayClick={() => handleStartGame('campaign', CAMPAIGN_LEVELS[0])}
              onArmoryClick={() => setShowArmory(true)}
            />

            <RulesAndGuidesSection
              onPlayClick={() => handleStartGame('campaign', CAMPAIGN_LEVELS[0])}
            />
          </main>

          <Footer
            onPlayClick={() => handleStartGame('campaign', CAMPAIGN_LEVELS[0])}
            onLevelsClick={() => setShowLevels(true)}
            onArmoryClick={() => setShowArmory(true)}
            onExportClick={() => setShowExportGuide(true)}
          />
        </div>
      )}

      {/* Armory Modal */}
      {showArmory && (
        <ArmoryModal
          currentSkin={currentSkin}
          onSelectSkin={handleSelectSkin}
          onClose={() => setShowArmory(false)}
        />
      )}

      {/* Levels and Game Mode Selector Modal */}
      {showLevels && (
        <LevelSelectorModal
          onSelectLevel={handleStartGame}
          onClose={() => setShowLevels(false)}
        />
      )}

      {/* Self-Hosting & Export Guide Modal */}
      {showExportGuide && (
        <ExportGuideModal
          onClose={() => setShowExportGuide(false)}
        />
      )}
    </div>
  );
}
