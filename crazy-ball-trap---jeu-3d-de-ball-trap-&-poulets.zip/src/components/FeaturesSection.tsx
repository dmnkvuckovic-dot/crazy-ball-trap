import React from 'react';
import { Target, Zap, Shield, Sparkles, Wind, Crosshair, Trophy, Award } from 'lucide-react';
import { soundEngine } from '../game/audio';

interface FeaturesSectionProps {
  onPlayClick: () => void;
  onArmoryClick: () => void;
}

export const FeaturesSection: React.FC<FeaturesSectionProps> = ({ onPlayClick, onArmoryClick }) => {
  return (
    <section id="presentation" className="py-20 px-4 lg:px-8 max-w-6xl mx-auto">
      {/* Section Header */}
      <div className="text-center max-w-3xl mx-auto">
        <h2 className="text-xs uppercase font-extrabold tracking-widest text-amber-400">
          IMMERSION & GAMEPLAY
        </h2>
        <p className="mt-2 text-3xl sm:text-4xl font-black text-white uppercase tracking-tight">
          LE VÉRITABLE BALL-TRAP SPORTIF REVISITÉ AVEC HUMOUR
        </p>
        <p className="mt-3 text-sm text-slate-300 leading-relaxed">
          Conçu avec un moteur 3D Three.js ultra-optimisé, <strong>CRAZY BALL TRAP</strong> combine la précision des règles du ball-trap olympique avec le fun déjanté des poulets de ferme cartoon !
        </p>
      </div>

      {/* Feature 1: 3D Environment & Physics */}
      <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-slate-900/70 border border-slate-800 rounded-3xl p-6 flex flex-col justify-between hover:border-slate-700 transition">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mb-4">
              <Target className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-extrabold text-white">Stand de Tir Réaliste</h3>
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">
              Trois fosses de lancement (gauche, centre, droite), pas de tir olympique avec balustrades en bois, indicateurs de distance (15m, 25m, 40m, 50m) et panorama montagneux avec sapins alpins.
            </p>
          </div>
          <div className="mt-6 pt-4 border-t border-slate-800 text-[11px] text-amber-300 font-mono flex items-center gap-1.5">
            <Wind className="w-3.5 h-3.5" /> Physique de vent latéral et gravité
          </div>
        </div>

        <div className="bg-slate-900/70 border border-slate-800 rounded-3xl p-6 flex flex-col justify-between hover:border-slate-700 transition">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-red-500/10 border border-red-500/30 flex items-center justify-center text-red-400 mb-4">
              <Zap className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-extrabold text-white">Poulets Déjantés & Cibles</h3>
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">
              Plateaux d’argile orange fluo qui éclatent en mille morceaux, poulets sprintant à grandes enjambées, volailles équipées de jetpacks supersoniques et poulets dorés légendaires !
            </p>
          </div>
          <div className="mt-6 pt-4 border-t border-slate-800 text-[11px] text-red-400 font-mono flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5" /> Plumes explosives et bruits "Cot-cot-codec !"
          </div>
        </div>

        <div className="bg-slate-900/70 border border-slate-800 rounded-3xl p-6 flex flex-col justify-between hover:border-slate-700 transition">
          <div>
            <div className="w-12 h-12 rounded-2xl bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400 mb-4">
              <Shield className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-extrabold text-white">Armurerie de Précision</h3>
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">
              Fusil superposé calibre 12 en noyer, modèle compétition carbone, version prestige en or 24 carats ou fusil tactique 6 coups. Recul dynamique, éjection des douilles et viseur de mire en laiton.
            </p>
          </div>
          <div className="mt-6 pt-4 border-t border-slate-800 text-[11px] text-sky-300 font-mono flex items-center gap-1.5">
            <Crosshair className="w-3.5 h-3.5" /> Visée ADS épaulée et hipfire réactif
          </div>
        </div>
      </div>

      {/* Target Gallery Banner */}
      <div className="mt-12 bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 border border-slate-800 rounded-3xl p-6 md:p-8">
        <h3 className="text-center text-sm font-extrabold uppercase text-amber-400 tracking-wider">
          LES CIBLES À ABATTRE SUR LE STAND
        </h3>

        <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
          <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-800/80">
            <div className="text-3xl mb-1">🎯</div>
            <h4 className="text-xs font-bold text-white">Plateau d'Argile</h4>
            <div className="text-[11px] text-amber-400 font-mono font-bold mt-1">+100 Pts</div>
            <p className="text-[10px] text-slate-400 mt-1">Trajectoire parabolique fuyante</p>
          </div>

          <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-800/80">
            <div className="text-3xl mb-1">🐔</div>
            <h4 className="text-xs font-bold text-white">Poulet Sprint</h4>
            <div className="text-[11px] text-amber-400 font-mono font-bold mt-1">+150 Pts</div>
            <p className="text-[10px] text-slate-400 mt-1">Court et saute sur le pas de tir</p>
          </div>

          <div className="p-4 bg-slate-950/60 rounded-2xl border border-slate-800/80">
            <div className="text-3xl mb-1">🚀</div>
            <h4 className="text-xs font-bold text-white">Poulet Rocket</h4>
            <div className="text-[11px] text-red-400 font-mono font-bold mt-1">+250 Pts</div>
            <p className="text-[10px] text-slate-400 mt-1">Traverse le ciel à toute allure</p>
          </div>

          <div className="p-4 bg-slate-950/60 rounded-2xl border border-amber-500/40 bg-amber-500/5">
            <div className="text-3xl mb-1">👑</div>
            <h4 className="text-xs font-bold text-amber-300">Poulet Doré Prestige</h4>
            <div className="text-[11px] text-amber-400 font-mono font-bold mt-1">+500 Pts + Munitions ∞</div>
            <p className="text-[10px] text-slate-400 mt-1">Déclenche 6s de tir illimité !</p>
          </div>
        </div>
      </div>
    </section>
  );
};
