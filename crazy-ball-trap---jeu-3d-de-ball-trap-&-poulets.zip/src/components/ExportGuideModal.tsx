import React, { useState } from 'react';
import { X, Globe, Copy, Check, Server, Download, ShieldCheck, ExternalLink } from 'lucide-react';

interface ExportGuideModalProps {
  onClose: () => void;
}

export const ExportGuideModal: React.FC<ExportGuideModalProps> = ({ onClose }) => {
  const [copiedCommand, setCopiedCommand] = useState(false);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCommand(true);
    setTimeout(() => setCopiedCommand(false), 2000);
  };

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center z-50 p-4">
      <div className="bg-slate-900 border border-slate-700 max-w-2xl w-full rounded-3xl p-6 md:p-8 shadow-2xl relative flex flex-col gap-5 max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl md:text-2xl font-black text-white uppercase tracking-wider">
                PUBLIER SUR VOTRE SITE WEB
              </h2>
              <p className="text-xs text-slate-400">
                100% Autonome • Zéro abonnement • Zéro clé API • Fichiers HTML/CSS/JS statiques
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Fermer"
            className="w-10 h-10 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Guarantees */}
        <div className="bg-emerald-950/30 border border-emerald-500/30 rounded-2xl p-4 flex items-start gap-3 text-xs text-emerald-200">
          <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          <div>
            <strong>Garantie 100% Open & Autonome :</strong> Ce jeu fonctionne intégralement en client-side (navigateur). Les sons sont générés en direct par l’API Web Audio de votre navigateur, les graphismes 3D tournent avec Three.js et WebGL. Aucun serveur payant, aucun abonnement ni clé API n’est requis.
          </div>
        </div>

        {/* Steps */}
        <div className="space-y-4">
          <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
              <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center text-xs">1</span>
              Générer les fichiers de production
            </div>
            <p className="text-xs text-slate-400 mt-2">
              Dans votre terminal, lancez la commande suivante pour compiler l’application en fichiers statiques ultra-rapides :
            </p>
            <div className="mt-2.5 flex items-center justify-between bg-slate-900 border border-slate-700 rounded-xl px-4 py-2.5 font-mono text-xs text-emerald-300">
              <span>npm run build</span>
              <button
                onClick={() => copyToClipboard('npm run build')}
                className="text-slate-400 hover:text-white flex items-center gap-1 text-[11px]"
              >
                {copiedCommand ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                {copiedCommand ? 'Copié !' : 'Copier'}
              </button>
            </div>
          </div>

          <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
              <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center text-xs">2</span>
              Récupérer le dossier /dist
            </div>
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">
              Le dossier <code className="text-amber-300 bg-slate-900 px-1 py-0.5 rounded">dist/</code> contient tout votre site prêt à l’emploi : <code className="text-amber-300 bg-slate-900 px-1 py-0.5 rounded">index.html</code>, les feuilles de style CSS et les scripts JS compilés.
            </p>
          </div>

          <div className="bg-slate-950/60 border border-slate-800 rounded-2xl p-4">
            <div className="flex items-center gap-2 text-amber-400 font-bold text-sm">
              <span className="w-6 h-6 rounded-full bg-amber-500/20 text-amber-400 flex items-center justify-center text-xs">3</span>
              Mettre en ligne sur votre hébergeur favori
            </div>
            <p className="text-xs text-slate-400 mt-2 leading-relaxed">
              Téléversez simplement le contenu du dossier <strong>dist/</strong> chez n’importe quel hébergeur :
            </p>
            <ul className="grid grid-cols-2 gap-2 mt-2.5 text-xs text-slate-300">
              <li className="flex items-center gap-1.5"><Server className="w-3.5 h-3.5 text-amber-400" /> Votre hébergeur FTP (OVH, etc.)</li>
              <li className="flex items-center gap-1.5"><Server className="w-3.5 h-3.5 text-amber-400" /> GitHub Pages (Gratuit)</li>
              <li className="flex items-center gap-1.5"><Server className="w-3.5 h-3.5 text-amber-400" /> Vercel / Netlify (Gratuit)</li>
              <li className="flex items-center gap-1.5"><Server className="w-3.5 h-3.5 text-amber-400" /> Hostinger / Infomaniak</li>
            </ul>
          </div>
        </div>

        {/* Close Button */}
        <div className="flex justify-end pt-2 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-6 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl transition active:scale-95 text-sm"
          >
            COMPRIS, J’AI TOUT POUR PUBLIER !
          </button>
        </div>
      </div>
    </div>
  );
};
