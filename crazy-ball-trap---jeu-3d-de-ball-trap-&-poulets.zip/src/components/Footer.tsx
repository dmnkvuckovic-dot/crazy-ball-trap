import React from 'react';
import { Target, Globe, Shield, Heart } from 'lucide-react';
import { soundEngine } from '../game/audio';

interface FooterProps {
  onExportClick: () => void;
  onArmoryClick: () => void;
  onLevelsClick: () => void;
  onPlayClick: () => void;
}

export const Footer: React.FC<FooterProps> = ({
  onExportClick,
  onArmoryClick,
  onLevelsClick,
  onPlayClick,
}) => {
  return (
    <footer className="border-t border-slate-800 bg-slate-950 py-12 px-4 lg:px-8 text-slate-400 text-xs">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        {/* Brand */}
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
            <Target className="w-5 h-5" />
          </div>
          <div>
            <div className="font-black text-sm text-white tracking-wider">CRAZY BALL TRAP 3D</div>
            <div className="text-[10px] text-slate-500">Jeu de Tir Sportif & Poulets Cartoon</div>
          </div>
        </div>

        {/* Quick Links */}
        <div className="flex flex-wrap items-center justify-center gap-5 font-semibold text-slate-300">
          <button
            onClick={() => {
              soundEngine.playUiClick();
              onPlayClick();
            }}
            className="hover:text-amber-400 transition"
          >
            Jouer
          </button>
          <button
            onClick={() => {
              soundEngine.playUiClick();
              onLevelsClick();
            }}
            className="hover:text-amber-400 transition"
          >
            Niveaux
          </button>
          <button
            onClick={() => {
              soundEngine.playUiClick();
              onArmoryClick();
            }}
            className="hover:text-amber-400 transition"
          >
            Armurerie
          </button>
          <button
            onClick={() => {
              soundEngine.playUiClick();
              onExportClick();
            }}
            className="text-emerald-400 hover:text-emerald-300 transition flex items-center gap-1"
          >
            <Globe className="w-3.5 h-3.5" /> Exporter pour mon site
          </button>
        </div>

        {/* Disclaimer & Copyright */}
        <div className="text-center md:text-right text-[11px] text-slate-500">
          <p>100% HTML, CSS & JavaScript • Zéro clé API • Zéro abonnement</p>
          <p className="mt-0.5">Jeu de simulation sportive et d'adresse humoristique</p>
        </div>
      </div>
    </footer>
  );
};
