import React from 'react';
import { X, Shield, Zap, Sparkles, Check } from 'lucide-react';
import { WeaponSkin } from '../game/types';
import { WEAPON_SKINS } from '../game/weapons';
import { soundEngine } from '../game/audio';

interface ArmoryModalProps {
  currentSkin: WeaponSkin;
  onSelectSkin: (skin: WeaponSkin) => void;
  onClose: () => void;
}

export const ArmoryModal: React.FC<ArmoryModalProps> = ({
  currentSkin,
  onSelectSkin,
  onClose,
}) => {
  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center z-50 p-4">
      <div className="bg-slate-900 border border-slate-700 max-w-3xl w-full rounded-3xl p-6 md:p-8 shadow-2xl relative flex flex-col gap-6">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500/20 border border-amber-500/40 flex items-center justify-center text-amber-400">
              <Shield className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-xl md:text-2xl font-black text-white uppercase tracking-wider">
                ARMURERIE DU STAND DE BALL-TRAP
              </h2>
              <p className="text-xs text-slate-400">
                Sélectionnez votre fusil de ball-trap de compétition ou déjanté
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            aria-label="Fermer"
            className="w-10 h-10 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Gun Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-h-[60vh] overflow-y-auto pr-1">
          {WEAPON_SKINS.map((skin) => {
            const isEquipped = currentSkin.id === skin.id;
            return (
              <div
                key={skin.id}
                onClick={() => {
                  soundEngine.playUiClick();
                  onSelectSkin(skin);
                }}
                className={`relative p-5 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between gap-3 ${
                  isEquipped
                    ? 'bg-amber-500/10 border-amber-500 shadow-[0_0_20px_rgba(245,158,11,0.2)]'
                    : 'bg-slate-950/60 border-slate-800 hover:border-slate-700 hover:bg-slate-950/90'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-extrabold text-white">{skin.name}</span>
                    {isEquipped && (
                      <span className="bg-amber-500 text-slate-950 text-[10px] font-black uppercase px-2 py-0.5 rounded-full flex items-center gap-1">
                        <Check className="w-3 h-3" /> ÉQUIPÉ
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-slate-400 mt-1.5 leading-relaxed">{skin.description}</p>
                </div>

                {/* Gun Preview Colors & Attributes */}
                <div className="flex items-center justify-between pt-3 border-t border-slate-800/80">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-4 h-4 rounded-full border border-white/20"
                      style={{ backgroundColor: skin.stockColor }}
                      title="Couleur Crosse"
                    />
                    <div
                      className="w-4 h-4 rounded-full border border-white/20"
                      style={{ backgroundColor: skin.barrelColor }}
                      title="Couleur Canons"
                    />
                    <div
                      className="w-4 h-4 rounded-full border border-white/20"
                      style={{ backgroundColor: skin.receiverColor }}
                      title="Couleur Bascule"
                    />
                  </div>

                  <div className="flex items-center gap-3 text-[11px] text-slate-300 font-mono">
                    <span className="flex items-center gap-1">
                      <Zap className="w-3 h-3 text-amber-400" /> {skin.capacity} Coups
                    </span>
                    <span className="flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-sky-400" /> x{skin.reloadSpeed} Cadence
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="flex justify-end pt-2 border-t border-slate-800">
          <button
            onClick={onClose}
            className="px-6 py-2.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl transition active:scale-95 text-sm"
          >
            VALIDER ET JOUER
          </button>
        </div>
      </div>
    </div>
  );
};
