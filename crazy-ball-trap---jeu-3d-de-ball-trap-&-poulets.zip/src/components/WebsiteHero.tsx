import React from 'react';
import { Play, Shield, Compass, Sparkles, CheckCircle2, Crosshair, Award, Flame, Globe } from 'lucide-react';
import { soundEngine } from '../game/audio';

interface WebsiteHeroProps {
  highScore: number;
  onPlayClick: () => void;
  onLevelsClick: () => void;
  onArmoryClick: () => void;
  onExportClick: () => void;
}

export const WebsiteHero: React.FC<WebsiteHeroProps> = ({
  highScore,
  onPlayClick,
  onLevelsClick,
  onArmoryClick,
  onExportClick,
}) => {
  return (
    <section className="relative overflow-hidden pt-12 pb-20 px-4 lg:px-8 border-b border-slate-800/60 bg-gradient-to-b from-slate-950 via-slate-900 to-slate-950">
      {/* Decorative background glows */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[350px] bg-gradient-to-tr from-amber-500/15 via-red-500/10 to-transparent blur-3xl pointer-events-none rounded-full" />

      <div className="max-w-6xl mx-auto flex flex-col items-center text-center relative z-10">
        {/* Top Feature Pill */}
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-bold mb-6 shadow-sm">
          <Sparkles className="w-3.5 h-3.5" />
          <span>VÉRITABLE JEU VIDÉO 3D FIRST-PERSON SHOOTER</span>
          <span className="hidden sm:inline text-slate-500">•</span>
          <span className="hidden sm:inline text-slate-300">100% Dans le Navigateur</span>
        </div>

        {/* Main Title */}
        <h1 className="text-4xl sm:text-6xl lg:text-7xl font-black text-white tracking-tight uppercase max-w-4xl leading-[1.08]">
          CRAZY <span className="bg-gradient-to-r from-amber-400 via-orange-500 to-red-500 bg-clip-text text-transparent">BALL TRAP</span>
        </h1>

        <p className="mt-5 text-base sm:text-xl text-slate-300 max-w-2xl leading-relaxed font-normal">
          Épaulez votre fusil de calibre 12, visez à la souris et pulvérisez les plateaux d'argile orange fluo et les poulets cartoon déjantés qui traversent le pas de tir !
        </p>

        {/* High Score Badge */}
        {highScore > 0 && (
          <div className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-slate-900/80 border border-amber-500/40 rounded-2xl text-amber-400 font-mono text-sm font-bold shadow-lg">
            <Award className="w-4 h-4" /> MEILLEUR SCORE ENREGISTRÉ : {highScore.toLocaleString()} PTS
          </div>
        )}

        {/* Main CTA Buttons */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3.5">
          <button
            onClick={() => {
              soundEngine.playUiClick();
              onPlayClick();
            }}
            className="px-8 py-4 rounded-2xl bg-gradient-to-r from-amber-500 via-orange-500 to-red-600 hover:from-amber-400 hover:to-red-500 text-slate-950 font-black text-base shadow-[0_0_30px_rgba(245,158,11,0.5)] transition active:scale-95 flex items-center gap-2.5 cursor-pointer"
          >
            <Play className="w-5 h-5 fill-slate-950" />
            <span>JOUER IMMÉDIATEMENT</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playUiClick();
              onLevelsClick();
            }}
            className="px-6 py-4 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-white font-extrabold text-sm transition active:scale-95 flex items-center gap-2"
          >
            <Compass className="w-4 h-4 text-amber-400" />
            <span>CHOISIR UN NIVEAU</span>
          </button>

          <button
            onClick={() => {
              soundEngine.playUiClick();
              onArmoryClick();
            }}
            className="px-6 py-4 rounded-2xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-white font-extrabold text-sm transition active:scale-95 flex items-center gap-2"
          >
            <Shield className="w-4 h-4 text-amber-400" />
            <span>ARMURERIE (4 FUSILS)</span>
          </button>
        </div>

        {/* Feature Highlights Grid */}
        <div className="mt-14 grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 w-full max-w-4xl text-left">
          <div className="bg-slate-900/60 border border-slate-800 p-4 rounded-2xl">
            <Crosshair className="w-5 h-5 text-amber-400 mb-2" />
            <h4 className="text-xs font-black text-white uppercase">Visée FPS Souris</h4>
            <p className="text-[11px] text-slate-400 mt-0.5">PointerLock & Zoom ADS avec décalage de recul</p>
          </div>
          <div className="bg-slate-900/60 border border-slate-800 p-4 rounded-2xl">
            <Flame className="w-5 h-5 text-red-400 mb-2" />
            <h4 className="text-xs font-black text-white uppercase">Poulets Déjantés</h4>
            <p className="text-[11px] text-slate-400 mt-0.5">Poulets rocket, parachutistes et golden chicken</p>
          </div>
          <div className="bg-slate-900/60 border border-slate-800 p-4 rounded-2xl">
            <Award className="w-5 h-5 text-emerald-400 mb-2" />
            <h4 className="text-xs font-black text-white uppercase">Combos & Records</h4>
            <p className="text-[11px] text-slate-400 mt-0.5">Multiplicateur x5 et sauvegarde locale du record</p>
          </div>
          <div
            onClick={() => {
              soundEngine.playUiClick();
              onExportClick();
            }}
            className="bg-slate-900/60 border border-emerald-500/40 p-4 rounded-2xl cursor-pointer hover:bg-slate-900 transition"
          >
            <Globe className="w-5 h-5 text-emerald-400 mb-2" />
            <h4 className="text-xs font-black text-white uppercase flex items-center gap-1">
              Export 100% Libre
            </h4>
            <p className="text-[11px] text-slate-400 mt-0.5">Hébergez sur votre propre site sans abonnement</p>
          </div>
        </div>
      </div>
    </section>
  );
};
