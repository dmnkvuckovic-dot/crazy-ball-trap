import React, { useState } from 'react';
import { X, Play, Wind, Target, Flame, Trophy, Compass, Star } from 'lucide-react';
import { CampaignLevel, GameDifficulty, GameMode } from '../game/types';
import { CAMPAIGN_LEVELS } from '../game/levels';
import { soundEngine } from '../game/audio';

interface LevelSelectorModalProps {
  onSelectLevel: (mode: GameMode, level?: CampaignLevel, difficulty?: GameDifficulty) => void;
  onClose: () => void;
}

export const LevelSelectorModal: React.FC<LevelSelectorModalProps> = ({
  onSelectLevel,
  onClose,
}) => {
  const [selectedMode, setSelectedMode] = useState<GameMode>('campaign');
  const [difficulty, setDifficulty] = useState<GameDifficulty>('normal');

  return (
    <div className="fixed inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center z-50 p-4">
      <div className="bg-slate-900 border border-slate-700 max-w-4xl w-full rounded-3xl p-6 md:p-8 shadow-2xl relative flex flex-col gap-6 max-h-[92vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-4">
          <div>
            <h2 className="text-xl md:text-3xl font-black text-white uppercase tracking-wider flex items-center gap-2">
              <Compass className="w-7 h-7 text-amber-400" /> CHOIX DU MODE & DES NIVEAUX
            </h2>
            <p className="text-xs text-slate-400 mt-1">
              Testez vos réflexes en campagne scénarisée, survivez en arcade ou entraînez votre visée
            </p>
          </div>
          <button
            onClick={onClose}
            aria-label="Fermer"
            className="w-10 h-10 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white flex items-center justify-center transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Mode Selector Tabs */}
        <div className="flex flex-wrap items-center justify-between gap-3 bg-slate-950/60 p-2 rounded-2xl border border-slate-800">
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                soundEngine.playUiClick();
                setSelectedMode('campaign');
              }}
              className={`px-4 py-2 rounded-xl text-xs md:text-sm font-extrabold transition flex items-center gap-2 ${
                selectedMode === 'campaign'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              <Target className="w-4 h-4" /> CAMPAGNE (5 NIVEAUX)
            </button>
            <button
              onClick={() => {
                soundEngine.playUiClick();
                setSelectedMode('arcade');
              }}
              className={`px-4 py-2 rounded-xl text-xs md:text-sm font-extrabold transition flex items-center gap-2 ${
                selectedMode === 'arcade'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              <Flame className="w-4 h-4" /> MODE ARCADE CHRONO
            </button>
            <button
              onClick={() => {
                soundEngine.playUiClick();
                setSelectedMode('training');
              }}
              className={`px-4 py-2 rounded-xl text-xs md:text-sm font-extrabold transition flex items-center gap-2 ${
                selectedMode === 'training'
                  ? 'bg-amber-500 text-slate-950 shadow-md'
                  : 'text-slate-400 hover:text-white hover:bg-slate-900'
              }`}
            >
              <Compass className="w-4 h-4" /> ENTRAÎNEMENT LIBRE
            </button>
          </div>

          {/* Difficulty selector */}
          <div className="flex items-center gap-1.5 text-xs text-slate-400">
            <span className="font-semibold text-[11px] uppercase mr-1">DIFFICULTÉ:</span>
            {(['easy', 'normal', 'hardcore'] as GameDifficulty[]).map((diff) => (
              <button
                key={diff}
                onClick={() => {
                  soundEngine.playUiClick();
                  setDifficulty(diff);
                }}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold uppercase transition ${
                  difficulty === diff
                    ? diff === 'hardcore'
                      ? 'bg-red-600 text-white'
                      : diff === 'easy'
                      ? 'bg-emerald-600 text-white'
                      : 'bg-amber-500 text-slate-950'
                    : 'bg-slate-900 text-slate-400 hover:text-white'
                }`}
              >
                {diff === 'easy' ? 'Facile' : diff === 'normal' ? 'Normal' : 'Hardcore'}
              </button>
            ))}
          </div>
        </div>

        {/* Campaign Levels List */}
        {selectedMode === 'campaign' && (
          <div className="space-y-3 max-h-[50vh] overflow-y-auto pr-1">
            {CAMPAIGN_LEVELS.map((lvl) => (
              <div
                key={lvl.id}
                onClick={() => {
                  soundEngine.playUiClick();
                  onSelectLevel('campaign', lvl, difficulty);
                }}
                className="group p-5 bg-slate-950/60 hover:bg-slate-950/90 border border-slate-800 hover:border-amber-500/80 rounded-2xl transition cursor-pointer flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
              >
                <div className="flex items-start gap-4">
                  <div className="w-12 h-12 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 font-mono font-black text-lg group-hover:scale-105 transition">
                    #{lvl.id}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base font-extrabold text-white group-hover:text-amber-400 transition">
                        {lvl.title}
                      </h3>
                      <div className="flex text-amber-400">
                        <Star className="w-3.5 h-3.5 fill-amber-400" />
                        <Star className="w-3.5 h-3.5 fill-amber-400" />
                        <Star className="w-3.5 h-3.5 fill-amber-400" />
                      </div>
                    </div>
                    <div className="text-xs text-amber-300/80 font-medium">{lvl.subtitle}</div>
                    <p className="text-xs text-slate-400 mt-1 max-w-xl">{lvl.description}</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 self-end md:self-center shrink-0">
                  <div className="text-right text-xs text-slate-400">
                    <div>Objectif: <strong className="text-white">{lvl.requiredScore} pts</strong></div>
                    <div className="flex items-center gap-1 justify-end text-slate-400 mt-0.5">
                      <Wind className="w-3 h-3 text-sky-400" /> Vent: {lvl.windSpeed} m/s
                    </div>
                  </div>

                  <button className="px-5 py-2.5 bg-amber-500 group-hover:bg-amber-400 text-slate-950 font-bold rounded-xl text-xs transition flex items-center gap-1.5 shadow-md">
                    <Play className="w-3.5 h-3.5 fill-slate-950" /> JOUER
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}

        {/* Arcade Mode Card */}
        {selectedMode === 'arcade' && (
          <div className="p-6 bg-slate-950/60 border border-slate-800 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-red-500/10 border border-red-500/30 text-red-400 text-xs font-bold">
                <Flame className="w-3.5 h-3.5" /> DÉFI SCORE RAPIDE
              </div>
              <h3 className="text-2xl font-black text-white">MODE ARCADE : 60 SECONDES DE FOLIE</h3>
              <p className="text-xs text-slate-300 leading-relaxed max-w-lg">
                Vous avez 60 secondes pour pulvériser un maximum de plateaux et de poulets fous. Chaque cible détruite augmente votre multiplicateur et vous offre du temps supplémentaire. Visez le record mondial !
              </p>
            </div>
            <button
              onClick={() => {
                soundEngine.playUiClick();
                onSelectLevel('arcade', undefined, difficulty);
              }}
              className="px-8 py-4 bg-gradient-to-r from-red-600 to-amber-500 hover:from-red-500 hover:to-amber-400 text-white font-extrabold rounded-2xl shadow-xl transition active:scale-95 flex items-center gap-2 text-sm shrink-0"
            >
              <Play className="w-5 h-5 fill-white" />
              <span>LANCER LE MODE ARCADE</span>
            </button>
          </div>
        )}

        {/* Training Mode Card */}
        {selectedMode === 'training' && (
          <div className="p-6 bg-slate-950/60 border border-slate-800 rounded-3xl flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="space-y-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-sky-500/10 border border-sky-500/30 text-sky-400 text-xs font-bold">
                <Compass className="w-3.5 h-3.5" /> STAND D'ENTRAÎNEMENT ILLIMITÉ
              </div>
              <h3 className="text-2xl font-black text-white">ENTRAÎNEMENT LIBRE SANS CHRONOMÈTRE</h3>
              <p className="text-xs text-slate-300 leading-relaxed max-w-lg">
                Aucun compte à rebours, aucune pression. Ajustez votre sensibilité de souris, apprenez le devancement des trajectoires et perfectionnez votre swing sans limite de temps.
              </p>
            </div>
            <button
              onClick={() => {
                soundEngine.playUiClick();
                onSelectLevel('training', undefined, difficulty);
              }}
              className="px-8 py-4 bg-sky-500 hover:bg-sky-400 text-slate-950 font-extrabold rounded-2xl shadow-xl transition active:scale-95 flex items-center gap-2 text-sm shrink-0"
            >
              <Play className="w-5 h-5 fill-slate-950" />
              <span>DÉMARRER L'ENTRAÎNEMENT</span>
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
