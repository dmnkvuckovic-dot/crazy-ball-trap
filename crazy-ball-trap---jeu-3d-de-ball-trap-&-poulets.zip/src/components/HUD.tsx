import React, { useEffect, useState } from 'react';
import { Target, Flame, RotateCcw, Volume2, VolumeX, Eye, Play, Home, Trophy, Crosshair, Award } from 'lucide-react';
import confetti from 'canvas-confetti';
import { FloatingText, GameStats, WeaponSkin } from '../game/types';
import { soundEngine } from '../game/audio';

interface HUDProps {
  stats: GameStats;
  ammo: number;
  maxAmmo: number;
  isReloading: boolean;
  isInfiniteAmmo: boolean;
  timeRemaining: number;
  levelName?: string;
  targetCount?: number;
  hitmarker: boolean;
  floatingTexts: FloatingText[];
  isLocked: boolean;
  isPaused: boolean;
  gameOver: { won: boolean; stats: GameStats } | null;
  currentSkin: WeaponSkin;
  onShoot: () => void;
  onReload: () => void;
  onToggleADS: () => void;
  onTogglePause: () => void;
  onRequestPointerLock: () => void;
  onRestart: () => void;
  onExitToMenu: () => void;
  onTouchLookDelta: (dx: number, dy: number) => void;
}

export const HUD: React.FC<HUDProps> = ({
  stats,
  ammo,
  maxAmmo,
  isReloading,
  isInfiniteAmmo,
  timeRemaining,
  levelName,
  targetCount,
  hitmarker,
  floatingTexts,
  isLocked,
  isPaused,
  gameOver,
  currentSkin,
  onShoot,
  onReload,
  onToggleADS,
  onTogglePause,
  onRequestPointerLock,
  onRestart,
  onExitToMenu,
  onTouchLookDelta,
}) => {
  const [muted, setMuted] = useState(soundEngine.isMuted);
  const [touchActive, setTouchActive] = useState(false);
  const [lastTouch, setLastTouch] = useState<{ x: number; y: number } | null>(null);

  useEffect(() => {
    if (gameOver && gameOver.won) {
      confetti({
        particleCount: 120,
        spread: 80,
        origin: { y: 0.6 },
      });
    }
  }, [gameOver]);

  const toggleSound = () => {
    const isNowMuted = soundEngine.toggleMute();
    setMuted(isNowMuted);
  };

  // Touch look pad handling for mobile
  const handleTouchStart = (e: React.TouchEvent) => {
    const touch = e.touches[0];
    setTouchActive(true);
    setLastTouch({ x: touch.clientX, y: touch.clientY });
  };

  const handleTouchMove = (e: React.TouchEvent) => {
    if (!lastTouch) return;
    const touch = e.touches[0];
    const dx = touch.clientX - lastTouch.x;
    const dy = touch.clientY - lastTouch.y;
    onTouchLookDelta(dx, dy);
    setLastTouch({ x: touch.clientX, y: touch.clientY });
  };

  const handleTouchEnd = () => {
    setTouchActive(false);
    setLastTouch(null);
  };

  return (
    <div className="absolute inset-0 pointer-events-none select-none overflow-hidden z-20 font-sans">
      {/* 1. TOP HEADER HUD: Score, Timer, Level Info, Audio toggle */}
      <div className="absolute top-0 left-0 right-0 p-3 md:p-6 flex items-start justify-between">
        {/* Score & Combo */}
        <div className="flex flex-col gap-1.5">
          <div className="bg-slate-900/85 backdrop-blur-md border border-amber-500/40 rounded-xl px-4 py-2.5 shadow-xl flex items-center gap-3">
            <Trophy className="w-5 h-5 text-amber-400" />
            <div>
              <div className="text-[10px] uppercase tracking-widest text-slate-400 font-semibold">SCORE</div>
              <div className="text-2xl md:text-3xl font-extrabold text-white tracking-wider font-mono">
                {stats.score.toLocaleString()}
              </div>
            </div>
          </div>

          {/* Combo Badge */}
          {stats.combo > 1 && (
            <div className="bg-gradient-to-r from-amber-500 to-red-600 text-white font-extrabold px-3 py-1 rounded-full text-xs md:text-sm flex items-center gap-1.5 shadow-lg animate-bounce w-fit">
              <Flame className="w-4 h-4 fill-white" />
              <span>COMBO x{Math.min(5, 1 + Math.floor(stats.combo / 3))} ({stats.combo} STREAK!)</span>
            </div>
          )}
        </div>

        {/* Center: Timer & Level Goal */}
        <div className="flex flex-col items-center">
          <div className={`px-5 py-2 rounded-2xl border backdrop-blur-md shadow-2xl flex items-center gap-2 ${
            timeRemaining <= 10
              ? 'bg-red-600/90 border-red-400 text-white animate-pulse'
              : 'bg-slate-900/85 border-slate-700 text-white'
          }`}>
            <span className="text-xs uppercase tracking-widest text-slate-300 font-semibold">TEMPS</span>
            <span className="text-2xl md:text-3xl font-mono font-bold">
              {Math.floor(timeRemaining / 60)}:{Math.floor(timeRemaining % 60).toString().padStart(2, '0')}
            </span>
          </div>

          {levelName && (
            <div className="mt-1 bg-black/60 px-3 py-1 rounded-full border border-slate-700/60 text-[11px] text-amber-300 font-medium">
              {levelName} {targetCount ? `• ${stats.claysHit + stats.chickensHit}/${targetCount} cibles` : ''}
            </div>
          )}
        </div>

        {/* Top Right: Accuracy & Audio & Pause */}
        <div className="flex items-center gap-2 pointer-events-auto">
          <div className="hidden sm:flex bg-slate-900/85 backdrop-blur-md border border-slate-700 rounded-xl px-3 py-2 items-center gap-2 text-white">
            <Target className="w-4 h-4 text-emerald-400" />
            <div className="text-right">
              <div className="text-[9px] uppercase tracking-widest text-slate-400">PRÉCISION</div>
              <div className="text-sm font-bold font-mono text-emerald-300">{stats.accuracy}%</div>
            </div>
          </div>

          <button
            onClick={toggleSound}
            aria-label="Toggle Sound"
            className="w-10 h-10 rounded-xl bg-slate-900/85 border border-slate-700 flex items-center justify-center text-white hover:bg-slate-800 transition active:scale-95"
          >
            {muted ? <VolumeX className="w-4 h-4 text-red-400" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>

          <button
            onClick={onTogglePause}
            aria-label="Pause"
            className="px-3 h-10 rounded-xl bg-slate-900/85 border border-slate-700 text-xs font-bold text-white hover:bg-slate-800 transition active:scale-95 flex items-center gap-1.5"
          >
            <span>PAUSE</span>
          </button>
        </div>
      </div>

      {/* 2. CENTER CROSSHAIR & HITMARKER */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="relative flex items-center justify-center">
          {/* Outer circle */}
          <div className="w-10 h-10 rounded-full border-2 border-white/60 flex items-center justify-center">
            {/* Center bead sight */}
            <div className="w-1.5 h-1.5 rounded-full bg-amber-400 shadow-[0_0_8px_#f59e0b]"></div>
          </div>
          {/* Radial tick marks */}
          <div className="absolute -top-3 w-0.5 h-2 bg-white/80"></div>
          <div className="absolute -bottom-3 w-0.5 h-2 bg-white/80"></div>
          <div className="absolute -left-3 w-2 h-0.5 bg-white/80"></div>
          <div className="absolute -right-3 w-2 h-0.5 bg-white/80"></div>

          {/* Hitmarker Flash */}
          {hitmarker && (
            <div className="absolute w-14 h-14 flex items-center justify-center animate-ping">
              <div className="absolute w-full h-0.5 bg-amber-400 rotate-45 shadow-[0_0_10px_#f59e0b]"></div>
              <div className="absolute w-full h-0.5 bg-amber-400 -rotate-45 shadow-[0_0_10px_#f59e0b]"></div>
            </div>
          )}
        </div>
      </div>

      {/* 3. FLOATING TEXTS (+100, +250 POULET!) */}
      {floatingTexts.map((item) => (
        <div
          key={item.id}
          className="absolute font-extrabold text-base md:text-xl drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)] animate-fade-up pointer-events-none"
          style={{
            left: `${item.x}px`,
            top: `${item.y}px`,
            color: item.color,
            transform: 'translate(-50%, -50%)',
          }}
        >
          {item.text}
        </div>
      ))}

      {/* 4. DESKTOP POINTER LOCK HINT */}
      {!isLocked && !isPaused && !gameOver && (
        <div className="absolute bottom-28 left-1/2 -translate-x-1/2 pointer-events-auto">
          <button
            onClick={onRequestPointerLock}
            className="bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-6 py-3 rounded-2xl shadow-2xl flex items-center gap-2 border border-amber-300 transition active:scale-95 animate-bounce"
          >
            <Crosshair className="w-5 h-5" />
            <span>CLIQUEZ POUR VISER À LA SOURIS (MODE FPS)</span>
          </button>
        </div>
      )}

      {/* 5. BOTTOM HUD: Ammo & Weapon & Controls */}
      <div className="absolute bottom-0 left-0 right-0 p-4 md:p-6 flex items-end justify-between pointer-events-none">
        {/* Left: Weapon Name & Stats */}
        <div className="hidden sm:flex flex-col gap-1 bg-slate-900/80 backdrop-blur-md border border-slate-700/80 rounded-2xl p-3 text-white max-w-xs">
          <div className="text-[10px] text-amber-400 uppercase tracking-widest font-bold">FUSIL ÉQUIPÉ</div>
          <div className="text-sm font-extrabold">{currentSkin.name}</div>
          <div className="text-[11px] text-slate-300 flex items-center gap-3 mt-1">
            <span>Plateaux: <strong>{stats.claysHit}</strong></span>
            <span>Poulets: <strong>{stats.chickensHit}</strong></span>
          </div>
        </div>

        {/* Center: Mobile Touch Look Surface (Full touch region) */}
        <div
          className="sm:hidden absolute inset-0 z-0 pointer-events-auto"
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
        />

        {/* Right: Cartridges / Ammo Counter */}
        <div className="relative z-10 flex flex-col items-end gap-2 pointer-events-auto">
          {/* Reloading banner */}
          {isReloading && (
            <div className="bg-red-600/90 text-white font-extrabold text-xs px-3 py-1.5 rounded-lg border border-red-400 shadow-xl flex items-center gap-1.5 animate-pulse">
              <RotateCcw className="w-3.5 h-3.5 animate-spin" />
              <span>RECHARGEMENT...</span>
            </div>
          )}

          {isInfiniteAmmo && (
            <div className="bg-amber-500 text-slate-950 font-black text-xs px-3 py-1 rounded-lg border border-amber-300 shadow-lg animate-bounce">
              ⚡ MUNITIONS INFINIES ACTIVES !
            </div>
          )}

          <div className="bg-slate-900/85 backdrop-blur-md border border-slate-700 rounded-2xl p-3 md:p-4 shadow-2xl flex items-center gap-3">
            {/* Visual 12-gauge Shells */}
            <div className="flex items-center gap-2">
              {Array.from({ length: maxAmmo }).map((_, idx) => {
                const isLoaded = idx < ammo;
                return (
                  <div
                    key={idx}
                    className={`w-4 h-12 md:w-5 md:h-14 rounded-sm border transition-all duration-200 flex flex-col justify-between p-0.5 ${
                      isLoaded
                        ? 'bg-red-700 border-red-500 shadow-[0_0_8px_rgba(239,68,68,0.5)]'
                        : 'bg-slate-800/60 border-slate-700 opacity-40'
                    }`}
                  >
                    {/* Brass rim head */}
                    <div className="w-full h-3 bg-amber-400 rounded-t-xs"></div>
                    <div className="w-full text-[8px] text-center font-bold text-white/60">12</div>
                  </div>
                );
              })}
            </div>

            <div className="border-l border-slate-700 pl-3">
              <div className="text-[10px] uppercase text-slate-400 font-semibold">MUNITIONS</div>
              <div className="text-2xl md:text-3xl font-extrabold text-white font-mono">
                {ammo} <span className="text-xs text-slate-500 font-normal">/ {maxAmmo}</span>
              </div>
            </div>

            {/* Desktop Reload Shortcut Hint */}
            <button
              onClick={onReload}
              disabled={isReloading || ammo === maxAmmo}
              className="ml-1 bg-slate-800 hover:bg-slate-700 disabled:opacity-40 text-amber-300 text-xs font-bold px-3 py-2 rounded-xl border border-slate-600 transition active:scale-95 flex items-center gap-1"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">[R]</span>
            </button>
          </div>
        </div>
      </div>

      {/* 6. MOBILE ACTION BUTTONS (TIRER, ZOOM, RECHARGER) */}
      <div className="sm:hidden absolute bottom-24 right-4 z-20 flex flex-col gap-3 pointer-events-auto">
        {/* Shoot Button */}
        <button
          onClick={onShoot}
          className="w-20 h-20 rounded-full bg-gradient-to-tr from-red-600 to-amber-500 text-white font-black text-sm shadow-[0_0_20px_rgba(239,68,68,0.6)] border-2 border-amber-300 flex flex-col items-center justify-center active:scale-90 transition"
        >
          <Crosshair className="w-7 h-7" />
          <span className="text-[10px] tracking-wider uppercase">TIRER</span>
        </button>

        {/* ADS / Zoom Button */}
        <button
          onClick={onToggleADS}
          className="w-14 h-14 rounded-full bg-slate-900/90 border border-slate-600 text-white flex flex-col items-center justify-center active:scale-90 transition self-end"
        >
          <Eye className="w-5 h-5 text-amber-400" />
          <span className="text-[8px] uppercase font-bold text-slate-300">ZOOM</span>
        </button>
      </div>

      {/* 7. PAUSE MODAL */}
      {isPaused && (
        <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-md flex items-center justify-center z-40 pointer-events-auto p-4">
          <div className="bg-slate-900 border border-slate-700 max-w-sm w-full rounded-3xl p-6 shadow-2xl text-center flex flex-col items-center gap-4">
            <h2 className="text-2xl font-black text-white uppercase tracking-wider">JEU EN PAUSE</h2>
            <p className="text-xs text-slate-400">Prenez votre souffle avant la prochaine volée de plateaux !</p>

            <div className="w-full flex flex-col gap-2 mt-2">
              <button
                onClick={onTogglePause}
                className="w-full py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl transition active:scale-95 flex items-center justify-center gap-2"
              >
                <Play className="w-4 h-4 fill-slate-950" />
                <span>REPRENDRE LA PARTIE</span>
              </button>

              <button
                onClick={onRestart}
                className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-white font-semibold rounded-xl border border-slate-700 transition active:scale-95 flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                <span>RECOMMENCER LE NIVEAU</span>
              </button>

              <button
                onClick={onExitToMenu}
                className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-xl border border-slate-700 transition active:scale-95 flex items-center justify-center gap-2"
              >
                <Home className="w-4 h-4" />
                <span>RETOURNER AU MENU DU SITE</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* 8. GAME OVER MODAL (VICTOIRE / DÉFAITE) */}
      {gameOver && (
        <div className="absolute inset-0 bg-slate-950/90 backdrop-blur-md flex items-center justify-center z-50 pointer-events-auto p-4 animate-fade-in">
          <div className="bg-slate-900 border-2 border-amber-500/80 max-w-md w-full rounded-3xl p-6 md:p-8 shadow-2xl text-center flex flex-col items-center gap-4">
            <div className={`w-16 h-16 rounded-full flex items-center justify-center ${
              gameOver.won ? 'bg-amber-500/20 text-amber-400 border border-amber-500' : 'bg-red-500/20 text-red-400 border border-red-500'
            }`}>
              {gameOver.won ? <Trophy className="w-8 h-8" /> : <Award className="w-8 h-8" />}
            </div>

            <div>
              <h2 className="text-3xl font-black text-white uppercase tracking-wider">
                {gameOver.won ? 'SESSION TERMINÉE !' : 'TEMPS ÉCOULÉ !'}
              </h2>
              <p className="text-xs text-slate-400 mt-1">
                {gameOver.won ? 'Belle adresse sur le stand de ball-trap !' : 'Entraînez-vous pour pulvériser plus de cibles !'}
              </p>
            </div>

            {/* Score Showcase */}
            <div className="w-full bg-slate-950/60 border border-slate-800 rounded-2xl p-4 flex flex-col gap-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-xs text-slate-400">Score Réalisé</span>
                <span className="text-2xl font-mono font-extrabold text-amber-400">
                  {gameOver.stats.score.toLocaleString()} pts
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2 text-left text-xs text-slate-300">
                <div>Plateaux détruits: <strong className="text-white">{gameOver.stats.claysHit}</strong></div>
                <div>Poulets touchés: <strong className="text-white">{gameOver.stats.chickensHit}</strong></div>
                <div>Précision du tir: <strong className="text-white">{gameOver.stats.accuracy}%</strong></div>
                <div>Combo Max: <strong className="text-white">x{gameOver.stats.maxCombo}</strong></div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="w-full flex flex-col sm:flex-row gap-2 mt-2">
              <button
                onClick={onRestart}
                className="flex-1 py-3 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold rounded-xl transition active:scale-95 flex items-center justify-center gap-2 shadow-lg"
              >
                <RotateCcw className="w-4 h-4" />
                <span>REJOUER</span>
              </button>
              <button
                onClick={onExitToMenu}
                className="flex-1 py-3 bg-slate-800 hover:bg-slate-700 text-white font-semibold rounded-xl border border-slate-700 transition active:scale-95 flex items-center justify-center gap-2"
              >
                <Home className="w-4 h-4" />
                <span>MENU DU SITE</span>
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
