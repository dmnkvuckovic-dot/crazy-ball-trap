import React from 'react';
import { Mouse, Smartphone, Sparkles, AlertCircle, Compass, Play, Crosshair, RotateCcw } from 'lucide-react';
import { soundEngine } from '../game/audio';

interface RulesAndGuidesSectionProps {
  onPlayClick: () => void;
}

export const RulesAndGuidesSection: React.FC<RulesAndGuidesSectionProps> = ({ onPlayClick }) => {
  return (
    <section id="regles" className="py-20 px-4 lg:px-8 max-w-6xl mx-auto border-t border-slate-800/80">
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto">
        <h2 className="text-xs uppercase font-extrabold tracking-widest text-amber-400">
          COMMANDES & ASTUCES DU TIREUR
        </h2>
        <p className="mt-2 text-3xl sm:text-4xl font-black text-white uppercase tracking-tight">
          COMMENT JOUER SUR ORDINATEUR ET MOBILE
        </p>
        <p className="mt-3 text-sm text-slate-300">
          Les commandes ont été pensées pour un confort absolu sur clavier/souris comme sur écran tactile de smartphone.
        </p>
      </div>

      {/* Dual Controls Grid */}
      <div className="mt-14 grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Desktop Controls */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 md:p-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Mouse className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black text-white">COMMANDES ORDINATEUR (PC / MAC)</h3>
              <p className="text-xs text-slate-400">Visée souris précise avec capture du pointeur (PointerLock)</p>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-slate-950/60 rounded-xl border border-slate-850 text-xs">
              <span className="text-slate-300 flex items-center gap-2">
                <Crosshair className="w-4 h-4 text-amber-400" /> Viser & Balayer le pas de tir
              </span>
              <kbd className="px-2 py-1 bg-slate-800 border border-slate-700 text-amber-300 font-mono font-bold rounded text-[11px]">
                Mouvement Souris
              </kbd>
            </div>

            <div className="flex items-center justify-between p-3 bg-slate-950/60 rounded-xl border border-slate-850 text-xs">
              <span className="text-slate-300 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-red-400" /> Faire feu / Tirer
              </span>
              <kbd className="px-2 py-1 bg-slate-800 border border-slate-700 text-red-300 font-mono font-bold rounded text-[11px]">
                Clic Gauche
              </kbd>
            </div>

            <div className="flex items-center justify-between p-3 bg-slate-950/60 rounded-xl border border-slate-850 text-xs">
              <span className="text-slate-300 flex items-center gap-2">
                <Crosshair className="w-4 h-4 text-sky-400" /> Épauler / Zoomer (ADS)
              </span>
              <kbd className="px-2 py-1 bg-slate-800 border border-slate-700 text-sky-300 font-mono font-bold rounded text-[11px]">
                Clic Droit
              </kbd>
            </div>

            <div className="flex items-center justify-between p-3 bg-slate-950/60 rounded-xl border border-slate-850 text-xs">
              <span className="text-slate-300 flex items-center gap-2">
                <RotateCcw className="w-4 h-4 text-emerald-400" /> Recharger le fusil
              </span>
              <kbd className="px-2.5 py-1 bg-slate-800 border border-slate-700 text-emerald-300 font-mono font-bold rounded text-[11px]">
                Touche [R]
              </kbd>
            </div>

            <div className="flex items-center justify-between p-3 bg-slate-950/60 rounded-xl border border-slate-850 text-xs">
              <span className="text-slate-300 flex items-center gap-2">
                <Compass className="w-4 h-4 text-slate-400" /> Mettre en Pause
              </span>
              <kbd className="px-2 py-1 bg-slate-800 border border-slate-700 text-slate-300 font-mono font-bold rounded text-[11px]">
                Échap / P
              </kbd>
            </div>
          </div>
        </div>

        {/* Mobile Controls */}
        <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 md:p-8">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 rounded-xl bg-sky-500/10 border border-sky-500/30 flex items-center justify-center text-sky-400">
              <Smartphone className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-black text-white">COMMANDES MOBILES & TABLETTES</h3>
              <p className="text-xs text-slate-400">Interface tactile ergonomique plein écran</p>
            </div>
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between p-3 bg-slate-950/60 rounded-xl border border-slate-850 text-xs">
              <span className="text-slate-300">Visée fluide</span>
              <span className="text-amber-400 font-medium">Glisser le doigt n'importe où</span>
            </div>

            <div className="flex items-center justify-between p-3 bg-slate-950/60 rounded-xl border border-slate-850 text-xs">
              <span className="text-slate-300">Bouton de tir</span>
              <span className="text-red-400 font-medium">Gros bouton rouge "TIRER"</span>
            </div>

            <div className="flex items-center justify-between p-3 bg-slate-950/60 rounded-xl border border-slate-850 text-xs">
              <span className="text-slate-300">Zoom précis</span>
              <span className="text-sky-400 font-medium">Bouton "ZOOM"</span>
            </div>

            <div className="flex items-center justify-between p-3 bg-slate-950/60 rounded-xl border border-slate-850 text-xs">
              <span className="text-slate-300">Rechargement</span>
              <span className="text-emerald-400 font-medium">Bouton "RECHARGER"</span>
            </div>

            <div className="flex items-center justify-between p-3 bg-slate-950/60 rounded-xl border border-slate-850 text-xs">
              <span className="text-slate-300">Orientation écran</span>
              <span className="text-slate-300 font-medium">Paysage recommandé</span>
            </div>
          </div>
        </div>
      </div>

      {/* Pro Tips Banner */}
      <div className="mt-8 bg-amber-500/10 border border-amber-500/30 rounded-3xl p-6 flex items-start gap-4">
        <AlertCircle className="w-6 h-6 text-amber-400 shrink-0 mt-0.5" />
        <div className="text-xs text-slate-300 leading-relaxed space-y-1.5">
          <strong className="text-amber-300 block text-sm">Astuce Pro de Ball-trap : Le Devancement (Lead)</strong>
          <p>
            Ne tirez pas là où se trouve le plateau, mais <strong>légèrement devant lui</strong> dans le sens de sa trajectoire ! À grande distance ou par vent fort, la gerbe de plombs met quelques dixièmes de seconde à atteindre sa cible.
          </p>
        </div>
      </div>

      {/* Bottom Play CTA */}
      <div className="mt-12 text-center">
        <button
          onClick={() => {
            soundEngine.playUiClick();
            onPlayClick();
          }}
          className="px-8 py-4 rounded-2xl bg-gradient-to-r from-amber-500 to-red-600 hover:from-amber-400 hover:to-red-500 text-slate-950 font-black text-base shadow-[0_0_25px_rgba(245,158,11,0.4)] transition active:scale-95 inline-flex items-center gap-2 cursor-pointer"
        >
          <Play className="w-5 h-5 fill-slate-950" />
          <span>COMMENCER LE TIR MAINTENANT</span>
        </button>
      </div>
    </section>
  );
};
