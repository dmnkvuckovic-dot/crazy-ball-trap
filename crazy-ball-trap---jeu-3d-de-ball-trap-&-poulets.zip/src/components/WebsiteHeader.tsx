import React from 'react';
import { Target, Shield, Compass, Globe, Play, Trophy, HelpCircle } from 'lucide-react';
import { soundEngine } from '../game/audio';

interface WebsiteHeaderProps {
  onPlayClick: () => void;
  onArmoryClick: () => void;
  onLevelsClick: () => void;
  onExportClick: () => void;
  onScrollToSection: (sectionId: string) => void;
}

export const WebsiteHeader: React.FC<WebsiteHeaderProps> = ({
  onPlayClick,
  onArmoryClick,
  onLevelsClick,
  onExportClick,
  onScrollToSection,
}) => {
  return (
    <header className="sticky top-0 z-40 bg-slate-950/85 backdrop-blur-md border-b border-slate-800/80 px-4 lg:px-8 py-3.5 flex items-center justify-between">
      {/* Brand Logo */}
      <div
        onClick={() => {
          soundEngine.playUiClick();
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        className="flex items-center gap-2.5 cursor-pointer group"
      >
        <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-red-600 flex items-center justify-center text-slate-950 shadow-[0_0_15px_rgba(245,158,11,0.5)] group-hover:scale-105 transition">
          <Target className="w-6 h-6 stroke-[2.5]" />
        </div>
        <div>
          <span className="text-xl font-black tracking-wider text-white flex items-center gap-1">
            CRAZY <span className="text-amber-400">BALL TRAP</span>
          </span>
          <span className="block text-[10px] uppercase tracking-widest text-slate-400 font-semibold -mt-1">
            JEU 3D DE TIR AU PLATEAU
          </span>
        </div>
      </div>

      {/* Navigation Links */}
      <nav className="hidden md:flex items-center gap-6 text-sm font-semibold text-slate-300">
        <button
          onClick={() => {
            soundEngine.playUiClick();
            onScrollToSection('presentation');
          }}
          className="hover:text-amber-400 transition"
        >
          Présentation
        </button>
        <button
          onClick={() => {
            soundEngine.playUiClick();
            onLevelsClick();
          }}
          className="hover:text-amber-400 transition flex items-center gap-1.5"
        >
          <Compass className="w-4 h-4 text-amber-400" />
          <span>Niveaux & Modes</span>
        </button>
        <button
          onClick={() => {
            soundEngine.playUiClick();
            onArmoryClick();
          }}
          className="hover:text-amber-400 transition flex items-center gap-1.5"
        >
          <Shield className="w-4 h-4 text-amber-400" />
          <span>Armurerie</span>
        </button>
        <button
          onClick={() => {
            soundEngine.playUiClick();
            onScrollToSection('regles');
          }}
          className="hover:text-amber-400 transition flex items-center gap-1.5"
        >
          <HelpCircle className="w-4 h-4 text-amber-400" />
          <span>Guide & Contrôles</span>
        </button>
        <button
          onClick={() => {
            soundEngine.playUiClick();
            onExportClick();
          }}
          className="text-emerald-400 hover:text-emerald-300 transition flex items-center gap-1.5 text-xs bg-emerald-950/40 border border-emerald-500/40 px-2.5 py-1 rounded-full"
        >
          <Globe className="w-3.5 h-3.5" />
          <span>Exporter le Jeu</span>
        </button>
      </nav>

      {/* Action CTA */}
      <div className="flex items-center gap-2.5">
        <button
          onClick={() => {
            soundEngine.playUiClick();
            onArmoryClick();
          }}
          className="hidden sm:flex px-3.5 py-2 rounded-xl border border-slate-700 bg-slate-900 hover:bg-slate-800 text-xs font-bold text-white transition active:scale-95 items-center gap-1.5"
        >
          <Shield className="w-3.5 h-3.5 text-amber-400" />
          <span>ARMURERIE</span>
        </button>

        <button
          onClick={() => {
            soundEngine.playUiClick();
            onPlayClick();
          }}
          className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-red-600 hover:from-amber-400 hover:to-red-500 text-slate-950 font-black text-xs md:text-sm shadow-[0_0_20px_rgba(245,158,11,0.4)] transition active:scale-95 flex items-center gap-2"
        >
          <Play className="w-4 h-4 fill-slate-950" />
          <span>JOUER MAINTENANT</span>
        </button>
      </div>
    </header>
  );
};
